         

         

         

         

         <!-- ***************** - Footer Starts Here - ***************** -->

         <footer role="contentinfo" id="footer">

            <div id="footer-callout" class="default-callout-link">

               <div id="footer-callout-content">

                  <a href="<?php echo BASETHEMEPATH;?>index.php/application" class="footer-callout-link">

                     <!--<p class="footer-callout-heading">Disclaimer</p>-->

                     <p>Disclaimer: Please note that we are not an affiliate of any official Government of Turkey service, embassy or government department. We provide without difficulty online visa registration services which will be verified by our service experts to avoid errors. Please refer to respective embassy and Visa fee information page. </p>

                  </a>

               </div><!-- END footer-callout-content -->

            </div><!-- END footer-callout -->

            

            <!--<div id="horizontal_nav">

				   <ul class="sub-menu">

					   <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7897" id="menu-item-7897"><a href="template-full-width.html">Full Width</a></li>

					  <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7846" id="menu-item-7846"><a href="index.html">Home</a></li>

					  <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7898" id="menu-item-7898"><a href="template-horizontal-nav.html">Horizontal Nav</a></li>

					  <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7899" id="menu-item-7899"><a href="template-faq-3.html">FAQ 3</a></li>

					  <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7847" id="menu-item-7847"><a href="template-left-nav.html">Left Nav</a></li>

					  <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7901" id="menu-item-7901"><a href="template-left-nav-sidebar.html">Left Nav + Sidebar</a></li>

					  <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7848" id="menu-item-7848"><a href="template-right-nav.html">Right Nav</a></li>

					  <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7902" id="menu-item-7902"><a href="template-right-nav-sidebar.html">Right Nav + Sidebar</a></li>

                      <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7847" id="menu-item-7847"><a href="template-left-nav.html">Left Nav</a></li>

					  <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7901" id="menu-item-7901"><a href="template-left-nav-sidebar.html">Left Nav + Sidebar</a></li>

					  <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7848" id="menu-item-7848"><a href="template-right-nav.html">Right Nav</a></li>

					  <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7902" id="menu-item-7902"><a href="template-right-nav-sidebar.html">Right Nav + Sidebar</a></li>

				   </ul>

				</div>-->

            <!-- END footer-content -->

      <div class="footer-overlay">
               <div class="footer-content">
                  <div class="one_third tt-column">
                     <h3>From the Blog</h3>
                     <div class="textwidget">
                        <div class="blog-posts-shortcode-outer-wrap">
                           <ul class="tt-recent-posts">
                              <li>
                                 <a href="<?php echo BASETHEMEPATH;?>index.php/blog" title="Responsive Website Template" class="tt-recent-post-link">
                                    <img class="tt-blog-sc-img" alt="Responsive Website Template" src="<?php echo BASETHEMEPATH;?>images/f1.jpg" width="65" height="65">
                                    <h4>Turkey Visa Requirements for UK</h4>
                                    <p>
                                      British nationals need a valid visa to fly Turkey, except...
                                    </p>
                                 </a>
                              </li>
                           </ul>
                           <ul class="tt-recent-posts">
                              <li>
                                 <a href="<?php echo BASETHEMEPATH;?>index.php/visa-processing" title="Responsive Website Template" class="tt-recent-post-link">
                                    <img class="tt-blog-sc-img" alt="Responsive Website Template" src="<?php echo BASETHEMEPATH;?>images/f2.jpg" width="65" height="65">
                                    <h4>How To Apply For A Turkey Visa</h4>
                                    <p>
                                      Open up your preferred browser and go to www.turkeyvisapro.com...
                                    </p>
                                 </a>
                              </li>
                           </ul>
                           <ul class="tt-recent-posts">
                              <li>
                                 <a href="<?php echo BASETHEMEPATH;?>index.php/visa-fees" title="Responsive Website Template" class="tt-recent-post-link">
                                    <img class="tt-blog-sc-img" alt="Responsive Website Template" src="<?php echo BASETHEMEPATH;?>images/f3.jpg" width="65" height="65">
                                    <h4>Turkish Visa Price List</h4>
                                    <p>
                                      To obtain your visa(s) for Turkey, please refer to the tables below to see...
                                    </p>
                                 </a>
                              </li>
                           </ul>
                        </div>
                        <br class="clear">
                     </div>
                  </div>
                  
                  
                  
                  <div class="one_third tt-column">
                     <h3>Quick Links</h3>
                      <div class="textwidget">
                     <ul class="tt-business-contact">
                     	 <li><a href="<?php echo BASETHEMEPATH;?>index.php">Home</a></li>
                        <li><a href="<?php echo BASETHEMEPATH;?>index.php/application">Apply Visa </a></li>
						<li><a href="<?php echo BASETHEMEPATH;?>index.php/application/check-status">Visa Status</a></li>
                       	<li><a href="<?php echo BASETHEMEPATH;?>index.php/about-us">About Us</a></li>
                        <li><a href="<?php echo BASETHEMEPATH;?>index.php/contact">Contact Us</a></li>
                        <li><a href="<?php echo BASETHEMEPATH;?>index.php/why-choose">Why Choose Us</a></li>
                        <li><a href="<?php echo BASETHEMEPATH;?>index.php/privacy">Privacy Policy</a></li>
                        <li><a href="<?php echo BASETHEMEPATH;?>index.php/terms">Terms & Conditions</a></li>
                     </ul>
                     </div>
                   <h3>Talk to us</h3>
                     <div class="textwidget">
                        <ul class="tt-business-contact">
                          
<div class="textwidget">
                        <ul class="tt-business-contact">
                           <li><a class="tt-biz-phone" href="tel://123-456-7890">0800 133 7567 (UK Customers Toll Free)</a></li>
                           <li><a class="tt-biz-email" href="mailto:#">info@turkeyvisapro.com</a></li>
                           
                        </ul>
  
                           
                        </ul>
                     </div>
                  </div>
                  
                  
                  
                  <div class="one_third_last tt-column">
                    <h3>Visa Fees</h3>
                     <div class="textwidget">
                        <ul class="tt-business-contact">
                          
                           
                           
                         <li><a href="#lightbox-unitedkingdom" class="lightboxlink">United Kingdom</a></li>
<li><a href="#lightbox-united" class="lightboxlink">Dubai</a></li>
<li><a href="#lightbox-saudia" class="lightboxlink">Saudi Arabia</a></li>
<li><a href="#lightbox-qatar" class="lightboxlink">Qatar</a></li>
 <li><a href="#lightbox-usa" class="lightboxlink">United States of America</a></li>
 <li><a href="#lightbox-norway" class="lightboxlink">Norway</a></li>
 <li><a href="#lightbox-canada" class="lightboxlink">Canada</a></li>
 <li><a href="#lightbox-netherlands" class="lightboxlink">Netherlands</a></li>
 <li><a href="<?php echo BASETHEMEPATH;?>index.php/visa-fees">More Countries</a></li>


                           
                        </ul>
                        
                     </div>
                     <!-- /mc_form_inside -->
                     <!-- /mc_signup_form -->
                  </div><!-- /mc_signup_container -->
               </div><!-- END mc_signup -->
               
               
            </div>

      

      

      

      

      <!-- ***************** - Footer Bottom Starts Here - ***************** -->

      

      <div id="footer_bottom">

            <div class="info">

            

                <div id="foot_left">&nbsp; Copyright &copy; 2014 Turkey Visa Pro. All rights reserved.                    

                </div><!-- END foot_left -->

                

                <div id="foot_right">

                   <div class="top-footer">

                      <a href="#" class="link-top">top</a>

                   </div>

                   <ul>

                      <li><a href="<?php echo BASETHEMEPATH;?>index.php/home">Home</a></li>

                      <li><a href="<?php echo BASETHEMEPATH;?>index.php/about-us">Abouts Us</a></li>

                      <li><a href="<?php echo BASETHEMEPATH;?>index.php/privacy">Privacy Policy</a></li>

                      <li><a href="<?php echo BASETHEMEPATH;?>index.php/terms">Terms and Conditions</a></li>

                   </ul>

                </div><!-- END foot_right -->

         </div><!-- END info -->

   

      </div><!-- END footer_bottom -->

</footer><!-- END footer -->

      



       

</div><!-- END wrapper -->

</div><!-- END tt-layout -->









<!-- ***************** - JavaScript Starts Here - ***************** -->

<script type="text/javascript" src="<?php echo BASETHEMEPATH;?>js/custom-main.js"></script>

<script type="text/javascript" src="<?php echo BASETHEMEPATH;?>js/superfish.js"></script>

<script type="text/javascript" src="<?php echo BASETHEMEPATH;?>js/jquery.flexslider.js"></script>

<script type="text/javascript" src="<?php echo BASETHEMEPATH;?>js/jquery.fitvids.js"></script>

<script type="text/javascript" src="<?php echo BASETHEMEPATH;?>js/scrollWatch.js"></script>

<script type="text/javascript" src="<?php echo BASETHEMEPATH;?>js/jquery.isotope.js"></script>

<script type="text/javascript" src="<?php echo BASETHEMEPATH;?>js/jquery.ui.core.min.js"></script>

<script type="text/javascript" src="<?php echo BASETHEMEPATH;?>js/jquery.ui.widget.min.js"></script>

<script type="text/javascript" src="<?php echo BASETHEMEPATH;?>js/jquery.ui.tabs.min.js"></script>

<script type="text/javascript" src="<?php echo BASETHEMEPATH;?>js/jquery.ui.accordion.min.js"></script>

<script type="text/javascript" src="<?php echo BASETHEMEPATH;?>js/jquery.prettyPhoto.js"></script>
            <script type="text/javascript" src="<?php echo BASETHEMEPATH;?>js/validation.js"></script>

<script>

jQuery(document).ready(function () {

    jQuery('.tt-parallax-text').fadeIn(1000); //delete this to remove fading content



    var $window = jQuery(window);

    jQuery('section[data-type="background"]').each(function () {

        var $bgobj = jQuery(this);



        jQuery(window).scroll(function () {

            var yPos = -($window.scrollTop() / $bgobj.data('speed'));

            var coords = '50% ' + yPos + 'px';

            $bgobj.css({

                backgroundPosition: coords

            });

        });

    });

});

</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-58437802-1', 'auto');
  ga('send', 'pageview');

</script>



<!--[if !IE]><!--><script>

  if (/*@cc_on!@*/false) {

	  document.documentElement.className+=' ie10';

  }

</script><!--<![endif]-->
<style type="text/css">
.apphead{
color:red;
border-bottom:1px solid #ccc;
padding-bottom:5px;}
        /* ---------------------------------------------------------- */
        /* LIGHTBOXES
        /* ---------------------------------------------------------- */
		.box td {
    border-bottom: 1px solid;
    border-top: 1px solid;
    text-align: center;
}
.right ul li span {
    float: right;
    font-weight: normal;
    text-align: right;
    width: 68%;
}

        #lightboxes {
        width: 100% !important;
        height: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
        list-style-type: none !important;
		overflow: auto !important;
        text-align: left !important;}

        #lightboxes li {
       position:fixed; /* keeps the lightbox window in the current viewport */
    top:0;
    left:0;
    width:100%;
    height:100%;
	display:none;
    text-align:center;
		}

        #lightboxes .box {
        width: 60% !important;
        height: 300px !important;
        margin: 0 auto !important;
		top: 26% !important;
        border: 10px solid #999 !important;
        background-color: #fff !important;
        padding: 20px !important;
		position: relative !important;
		z-index: 1000 !important;}

        #lightboxes #close {
        background-color: transparent;
        z-index: -1;}

        /* ---------------------------------------------------------- */
        /* PRETTY STUFF
        /* ---------------------------------------------------------- */
      
   

        
        #lightboxes h3 {
        font-weight: normal;
        font-size: 1.8461em;
        margin: 0 0 0.4583em 0;}
        
        #lightboxes a.close {
        float: right;
        display: block;
        width: 20px;
        line-height: 20px;
        text-align: center;
        background-color: #ddd;
        text-decoration: none;
        font-weight: bold;
        color: #999;
        font-size: 1.2em;}
        
        #lightboxes a.close:hover {
        background-color: #999;
        color: #fff;}

    </style>

    <!--[if IE]>
    <style type="text/css">
        html {
        overflow-y: auto;}
        
        #lightboxes {
        position: relative;
        overflow: hidden;} 

        #lightboxes .ie-bg {
        background: #000;
        position: absolute;
        width: 100%;
        height: 3000px;
        filter: alpha(opacity=75);
        top: 0;
        left: 0;}
    </style>
    <![endif]-->  
<script>
jQuery(document).ready(function(){
jQuery('.lightboxlink').click(function(){
	var divid=jQuery(this).attr('href');
	jQuery(divid).show();
	});
	jQuery('.close').click(function(){
jQuery('.lightboxdiv').hide();
		});
    });</script>
<script type='text/javascript'>window._sbzq||function(e){e._sbzq=[];var t=e._sbzq;t.push(["_setAccount",14577]);var n=e.location.protocol=="https:"?"https:":"http:";var r=document.createElement("script");r.type="text/javascript";r.async=true;r.src=n+"//static.subiz.com/public/js/loader.js";var i=document.getElementsByTagName("script")[0];i.parentNode.insertBefore(r,i)}(window);</script>
<ul id="lightboxes">
                        <li class="lightboxdiv"id="lightbox-netherlands">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Netherlands</h3>
            <p>  Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month-multiple entry turkeyvisapro the website www.turkeyvisapro.com Official passport holders are exempt from visa for their travels up to 90 days.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
                        <li class="lightboxdiv"id="lightbox-canada">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Canada</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders can obtain three-month multiple entry e-Visas via the website www.turkeyvisapro.com
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60 </td>
						<td>180</td>
						<td>90</td>
						<td>Single-Entry</td>  	 		
					  </tr>
				</table> 
        </div>
    </li>
                        <li class="lightboxdiv"id="lightbox-norway">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Norway</h3>
            <p>  Official passport holders are exempt from visa for their travels up to 90 days. Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month-multiple entry e-Visas via the website www.evisa.gov.tr and stay in Turkey up to 90 days within 6 months starting from the first entry date.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
                        <li class="lightboxdiv"id="lightbox-usa">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>U.S.A</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey. They can obtain three month-multiple entry visas from Turkish diplomatic representations abroad and also via the website www.turkeyvisapro.com
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$55.00 </td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry</td>  	
					  </tr>
				</table> 
        </div>
    </li>
                        <li class="lightboxdiv"id="lightbox-qatar">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Qatar</h3>
            <p>  Diplomatic, service and special passport holders are exempted from visa for their travels with touristic purposes and transit to/from Turkey up to 90 days within six months, starting from the first entry date. Ordinary passport holders are required to have visa to enter Turkey. Ordinary passport holders may get their three-month multiple entry e-Visas via the website www.turkeyvisapro.com   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$28.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
                       <li class="lightboxdiv"id="lightbox-saudia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Saudi Arabia</h3>
            <p>  Official passport holders are exempted from visa for their travels to Turkey with touristic purposes up to 90 days within 180 days, starting from the first entry date. Ordinary passport holders are required to have visa to enter Turkey. They can obtain their three month period multiple entry e-Visas via the website www.turkeyvisapro.com  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$90.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple </td>
					  </tr>
				</table> 
        </div>
    </li>
    <li class="lightboxdiv"id="lightbox-united">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>United Arab Emirates</h3>
            <p>  Official passport holders are exempted from visa for their travels up to 90 days. Ordinary passport holders are required to have visa to enter Turkey. Ordinary passport holders can obtain their three-month period multiple entry e-Visas via the website www.turkeyvisapro.com </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$90.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple </td>
					  </tr>
				</table> 
        </div>
    </li>
                        <li class="lightboxdiv"id="lightbox-unitedkingdom">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>United Kingdom</h3>
            <p>Diplomatic passport holders are exempted from visa for their travels up to 90 days. Ordinary, service and special passport holders are required to have visa to enter Turkey. Ordinary passport holders can obtain three month-multiple entry e-Visas via the website www.turkeyvisapro.com
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180</td>
						<td>90</td>
						<td>Multiple</td>  	
					  </tr>
				</table> 
        </div>
    </li>
                        </ul>
</body>

</html>