<!-- ***************** - Main Content Area - ***************** -->
<div class="main">
<div class="main-area">
			
               <main role="main" id="content" class="content_full_width">
                 
                
                  
                
                  
                  <!-- END callout-wrap --><br class="clear" />
                  
                  
                 <!-- <div class="hr_gap" style="height:30px;"></div>-->
                  <div class="one_half tt-column">
                     <img src="<?php echo BASETHEMEPATH;?>images/turkey-visa-online.jpg">
                  </div>
				  
				  <style>
				  .step-num {
						display: table-cell;
						height: 40px;
						padding-right: 5px;
						width: 40px;
						background-color: rgb(236, 36, 39);
						border-radius: 50%;
						color: rgb(255, 255, 255);
						display: block;
						font-size: 20px;
						height: 40px;
						line-height: 40px;
						text-align: center;
						width: 40px;
					}
					.text
					{
					float: right;
					   margin-left: 60px;
						margin-top: -62px;
					}
				  </style>
                  <div class="one_half_last tt-column">
                     <h3>Visa Processing for Turkey</h3>
					 
                     <div class="blog-posts-shortcode-outer-wrap">
                        <ul class="tt-recent-posts">
                           <li>
                              <a class="tt-recent-post-link" title="Apply Turkey Visa" href="http://turkeyvisapro.com/index.php/application">
                                 <div class="step-num">
									<span class="number">1</span>
								 </div>
								 <div class="text">
                                <h5 class="item-title"><strong><span style="color: #da0000;">Open up your preferred browser and go to www.turkeyvisapro.com</span></strong></h5>
                                 <p>Click Apply now then select the country and the passport or identity card (of the chosen country) you will be using. Then click on &quot;Continue&quot;</p>
							</div>
                              </a>
                           </li>
                        </ul>
                        <ul class="tt-recent-posts">
                           <li>
                              <a class="tt-recent-post-link" title="Metro Design Style" href="http://turkeyvisapro.com/index.php/application">
                                 
								 <div class="step-num">
									<span class="number">2</span>
								 </div>
								 <div class="text">
                                 <h5 class="item-title"><strong><span style="color: #da0000;">Enter your travel dates</span></strong></h5>
									<p>At this point, you will get quite a bit of important information: Enter your personal data. All fields are obligatory. If they are used in your passport or identity card number then press the button at the bottom to continue.</p>
									</div>
                              </a>
                           </li>
                        </ul>
                        <ul class="tt-recent-posts">
                           <li>
                              <a class="tt-recent-post-link" title="Optimize WordPress" href="http://turkeyvisapro.com/index.php/application">
                                 <div class="step-num">
									<span class="number">3</span>
								 </div>
								 <div class="text">
                                 <h5 class="item-title"><strong><span style="color: #da0000;">Once you review screen appear, all data has been accepted and you are good to go</span></strong></h5>
									 <p>You have one last chance to review the information you provided. Take your time to check it all. A small mistake may cause problems at the border! Click &quot;Edit&quot; if you need to change something, &quot;Verify&quot; to submit and continue.</p>
								</div>
							  </a>
                           </li>
                        </ul>
                        
						 <ul class="tt-recent-posts">
                           <li>
                              <a class="tt-recent-post-link" title="Optimize WordPress" href="http://turkeyvisapro.com/index.php/application">
                                 <div class="step-num">
									<span class="number">4</span>
								 </div>
								 <div class="text">
                                 <h5 class="item-title"><strong><span style="color: #da0000;">At this point, your application has been submitted for conformation</span></strong></h5>
                                 <p>Check your email immediately. If you did not receive mail within few minutes, check your spam folder because PDF attached will bethere, some times your email serivce providers will send them spam / junk.</p>
								 
								 </div>
                                 
                             </a> </li>
						 </ul>
                         
                         <ul class="tt-recent-posts">
                           <li>
                              <a class="tt-recent-post-link" title="Metro Design Style" href="http://turkeyvisapro.com/index.php/application">
                                 
								 <div class="step-num">
									<span class="number">5</span>
								 </div>
								 <div class="text">
                                 <h5 class="item-title"><strong><span style="color: #da0000;">Once your payment has been approved and details checked by expert</span></strong></h5>
									<p>you will get e-Visa by email with a button to download it. In case you fail to download it, no worries, you can always download it again via the link provided to you by email but you have Adobe PDF for sure in your machine.</p>
									</div>
                              </a>
                           </li>
                        </ul>






<ul class="tt-recent-posts">
                           <li>
                              <a class="tt-recent-post-link" title="Metro Design Style" href="http://turkeyvisapro.com/index.php/application">
                                 
								 <div class="step-num">
									<span class="number">6</span>
								 </div>
								 <div class="text">
                                 <h5 class="item-title"><strong><span style="color: #da0000;">Finally open the saved/downloaded Adobe PDF document and print it</span></strong></h5>
									<p>But make sure you take it with you, and keep together with your passport or identity card.</p>
									</div>
                              </a>
                           </li>
                        </ul>







                     </div>
                     <a class="ka_button small_button small_cherry" href="<?php echo BASETHEMEPATH;?>index.php/application">Apply Now!</a>
                     <br class="clear" />
                  </div>
                  <br class="clear" />
                  <p>&nbsp;</p>
                  
                  
                  <!-- ////////////////////////////////////////////////////////// -->
                  <!-- ***************** - Content Ends Here - ****************** -->
                  <!-- ////////////////////////////////////////////////////////// -->               
               
               
               

               
               </main><!-- END main #content -->
            </div><!-- END main-area -->
            
            



  

  <div id="footer-top">&nbsp;</div>

</div>

<!-- END main --> 