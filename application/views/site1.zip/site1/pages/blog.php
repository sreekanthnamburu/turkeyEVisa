<div class="tt-slider-" id="main">			<div class="main-area" style="position: relative;"> 
<!-- ////////////////////////////////////////////////////////// -->              <!-- ***************** - Content Start Here - ***************** -->      
        <!-- ////////////////////////////////////////////////////////// -->                      
		<!-- ***************** - Breadcrumbs Start Here - ***************** -->      
		<div class="tools">				
			<span class="tools-top"></span>				
				<div class="frame">					
					<h1>Blog</h1>					
						<!--<form class="search-form" action="template-blog.html" method="get" role="search">		
							<fieldset>				
								<label for="s">Search this website</label>			
									<span class="text">				
										<input type="text" onblur="this.value=(this.value=='') ? 'Search' : this.value;" onfocus="this.value=(this.value=='Search') ? '' : this.value;" value="Search" id="s" class="s" name="s">		
										<input type="submit" class="searchsubmit" value="search">				
									</span>				
							</fieldset>			
						</form>	-->			
						<a class="ka_button small_button small_cherry search_form" href="<?=base_url();?>index.php/application">Apply Now</a><p class="breadcrumb"><a href="<?php echo BASETHEMEPATH;?>index.php/home">Home</a><a href="<?php echo BASETHEMEPATH;?>index.php/about-us">About Us</a><span class='current_crumb'>Blog</span>	
					</div><!-- END frame -->		
					<span class="tools-bottom"></span>			
		</div><!-- END tools -->							
		<main class="content_blog" id="content" role="main">			
			<article class="blog_wrap  post-6645 post type-post status-publish format-standard hentry category-blog-posts tag-responsive tag-themeforest tag-wordpress">
				<div class="post_title">				
					<h2><a  href="http://turkeyvisapro.com/index.php/application">Turkey Visa Requirements for UK Citizens</a></h2>
				  <p class="posted-by-text"><span>Posted by:</span> <a rel="author" title="Posts by TrueThemes" href="#">TurkeyVisaPro</a></p>	
				</div><!-- END post_title -->				 
				<div class="post_content">			
					<div class="modern_img_frame tt-blog-featured">					
						<div class="img-preload"><a class="attachment-fadeIn" title="Responsive WordPress Theme" href="http://turkeyvisapro.com/index.php/application" style="display: inline;">
							<img width="538" height="218" alt="Responsive WordPress Theme" src="<?php echo BASETHEMEPATH;?>images/Blog/Blog-1.jpg"></a>						</div>
					  <!-- END img-preload -->		
					</div><!-- END post_thumb -->			
						<p>British nationals need a valid visa to fly Turkey, except for cruise ship passengers with British Citizen passports entering the country for a day trip, remaining in the port of embarkation and returning to the ship the same day.</p>
                        
                        
<p>An e-visa costs $20 and you can pay using a credit or debit card. You can apply up to 3 months in advance of your travel date. Turkish visit visas issued on arrival are valid for multiple stays up to a maximum of 90 days in a 180 day period.</p>	
	
						<!-- <p>At first, the idea of designing and developing a fully responsive, mobile-ready WordPress ...</p>-->		
						
                        <a class="ka_button small_button small_cherry" href="#">More</a>
									
		  <div class="post_date">						
							<span class="day">2</span>		
							<br>					
							<span class="month">DEC</span>				
						</div><!-- END post_date -->					
						<!-- END post_comments -->			
				</div><!-- END post_content -->		
				
				<div class="post_footer"> </div><!-- END post_footer -->	
			</article><!-- END blog_wrap -->				

			<article class="blog_wrap  post-6647 post type-post status-publish format-standard hentry category-blog-posts tag-design tag-retina tag-wordpress">			
				<div class="post_title">	
					<h2><a title="Metro Design Style" href="http://turkeyvisapro.com/index.php/application">How To Apply For A Turkey Visa</a></h2>		
				  <p class="posted-by-text"><span>Posted by:</span> <a rel="author" title="Posts by TrueThemes" href="http://turkeyvisapro.com/index.php/application">TurkeyVisaPro</a></p>
			  </div><!-- END post_title -->	
				
				<div class="post_content">			
					<div class="modern_img_frame tt-blog-featured">
						<div class="img-preload"><a class="attachment-fadeIn" title="Metro Design Style" href="http://turkeyvisapro.com/index.php/application" style="display: inline;">
							<img width="538" height="218" alt="Metro Design Style" src="<?php echo BASETHEMEPATH;?>images/Blog/Blog-2.jpg"></a>						</div>
					  <!-- END img-preload -->				
					</div><!-- END post_thumb -->			
						<ul class="list list1">

 

<li>Open up your preferred browser and go to www.turkeyvisapro.com</li>


<li>Enter your travel dates</li>


<li>Once you review screen appear, all data has been accepted and you are good to go</li>


<li>At this point, your application has been submitted for conformation</li>


<li>Once your payment has been approved and details checked by expert</li>


<li>Finally open the saved/downloaded Adobe PDF document and print it</li>


</ul>
						<!--<p>To get started, it&#8217;s important to understand the vision and purpose of the Metro style. This is outlined in a set of Metro design ...</p>-->		
							<a class="ka_button small_button small_cherry" href="#">More</a>		
  <div class="post_date">			
									<span class="day">9</span>		
										<br>					
									<span class="month">NOV</span>		
								</div><!-- END post_date -->		

								<!-- END post_comments -->			
				</div><!-- END post_content -->			
				<div class="post_footer"></div><!-- END post_footer -->		
			</article><!-- END blog_wrap -->
			
			<article class="blog_wrap  post-6649 post type-post status-publish format-standard hentry category-blog-posts tag-themes tag-truethemes tag-wordpress">			
				<div class="post_title">			
					<h2><a title="Optimize WordPress" href="http://turkeyvisapro.com/index.php/application">Turkish Visa Price List</a></h2>	
				  <p class="posted-by-text"><span>Posted by:</span> <a rel="author" title="Posts by TrueThemes" href="#">TurkeyVisaPro</a></p>	
				</div><!-- END post_title -->		
				<div class="post_content">				
					<div class="modern_img_frame tt-blog-featured">		
						<div class="img-preload"><a class="attachment-fadeIn" title="Optimize WordPress" href="http://turkeyvisapro.com/index.php/application" style="display: inline;">
							<img width="538" height="218" alt="Optimize WordPress" src="<?php echo BASETHEMEPATH;?>images/Blog/Blog-3.jpg"></a>						</div>
					  <!-- END img-preload -->
					</div><!-- END post_thumb -->				
					<p>To obtain your visa(s) for Turkey, please refer to the tables below to see the Embassy fee amount which are not included professional services.</p>	
					<!--<p>From the coders perspective WordPress is pretty darned fast compared with other platforms� but still we can optimize the WordPress sites using common ...</p>-->			
						<a class="ka_button small_button small_cherry" href="#">More</a>			
						<div class="post_date">					
							<span class="day">28</span>			
							<br>						
							<span class="month">NOV</span>		
						</div><!-- END post_date -->					  
						<!-- END post_comments -->			
					</div><!-- END post_content -->			
					<!-- END post_footer -->		
			</article><!-- END blog_wrap -->	
			
			<article class="blog_wrap  post-6649 post type-post status-publish format-standard hentry category-blog-posts tag-themes tag-truethemes tag-wordpress"><!-- END post_title -->
              <!-- END post_content -->
			  <div class="post_footer"></div><!-- END post_footer -->		
			</article><!-- END blog_wrap -->	

			<article class="blog_wrap  post-6649 post type-post status-publish format-standard hentry category-blog-posts tag-themes tag-truethemes tag-wordpress">
			  <!-- END post_title -->
			  <!-- END post_content -->				   		
				
			</article><!-- END blog_wrap -->
		  <!-- END blog_wrap -->				
	  <div class="karma-pages">			
				<span class="pages">Page 1 of 2</span>&nbsp;<span class="current">1</span><a title="2" class="page" href="#">2</a>	
			</div>				
				
				<br class="clear">
		  <!-- ////////////////////////////////////////////////////////// -->   
          <!-- ***************** - Content Ends Here - ****************** -->           
          <!-- ////////////////////////////////////////////////////////// -->       
        </main>
		<!-- END main #content -->                      
			 <aside class="sidebar_blog" id="sidebar" role="complementary">
                                  <div class="sidebar-widget">        
               <div class="tt-icon-box">
						  <span class="fa-stack fa-5x"><i style="color:#E15258;" class="fa fa-circle fa-stack-2x"></i><i class="fa fa-thumbs-o-up fa-stack-1x fa-inverse"></i></span>
						  <h1>3 steps away from a Turkey visa.</h1>
						  <p><strong>Fill out the Secured Form</strong> -  No documents to send off.  <strong>Confirm And Pay</strong> - Get Turkey <strong>Visa by Email</strong></p>
					   </div>
                </div>

				  
					 

				   

				   

							<div class="sidebar-widget">

                            <div class="inner- wrapper">
							<div class="tt-icon-box">
                            <a href="<?php echo BASETHEMEPATH;?>index.php/application"><img src=" <?php echo BASETHEMEPATH;?>images/secure.jpg"></a>

							</div>
							</div>
								</div>

						   

						    <div class="sidebar-widget">                 

								<div class="module_round_box_outer">

								<div class="module_round_box">

								<div class="s5_module_box_1">

								<div class="s5_resize_below_columns_inner s5_module_box_2" style="min-height: 313px;">

								<div class="s5_mod_h3_outer">

								<h3 class="s5_mod_h3"><span class="s5_h3_first">FAQS </span></h3>

								</div>

																				

								<ul class="menu">

								<li class="item-343"><a href="<?php echo BASETHEMEPATH;?>index.php/faq">Can I apply for a student or a job e-Visa?</a></li>

								<li class="item-344"><a href="<?php echo BASETHEMEPATH;?>index.php/faq">How much does cost e-visa?</a></li>

								<li class="item-129"><a href="<?php echo BASETHEMEPATH;?>index.php/faq">
How many days my Turkish e-visa valid?</a></li>

								<li class="item-128"><a href="<?php echo BASETHEMEPATH;?>index.php/faq">Can I have a look Sample e-Visa?</a></li>

								

								</ul>

								  <a href="<?php echo BASETHEMEPATH;?>index.php/faq" class="ka_button small_button small_cherry">Read More</a>

								</div>

								</div>

								</div>

								</div>  

							</div>

				   

					<!--<div class="sidebar-widget">

						<div class="module_round_box_outer">

								<div class="module_round_box">

										<div class="s5_module_box_1">

												<div style="min-height: 313px;" class="s5_resize_below_columns_inner s5_module_box_2">

														<div class="s5_mod_h3_outer">

														<h3 class="s5_mod_h3"><span class="s5_h3_first">Apply With Confidence</span></h3>

														</div>

																										



														<div class="jlnews_slider">

															<div style="height: 1560px; top: -780px;" id="jlnews_slider">

																		<span class="">

																	<a title="Lawyer Application" class="" href="#">

																		Lawyer Application			</a>

																	<div><p>Begonia information systems is in final stages of launching a revolutionary application for lawyers / advocates which enable them to supervise and control their day to day office activities, getting and storing all their data at one place and make to reminders to their clients about their cases. This wonderful concept will be launched very soon in the market.</p> ...</div>

																</span>

																

																	</div>

																	</div>

																	

												</div>

										</div>

								</div>

						</div>

					</div>-->

                 

<div class="sidebar-widget">                 

<div class="module_round_box_outer">

<div class="module_round_box">

<div class="s5_module_box_1">

<div class="s5_resize_below_columns_inner s5_module_box_2" style="min-height: 313px;">

<div class="s5_mod_h3_outer">

<h3 class="s5_mod_h3"><span class="s5_h3_first">Apply With Confidence </span></h3>

</div>

												

<ul class="menu">

<li class="item-343"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Video Email Marketing">Safety, Fastest, Reliable, Save Time.</a></li>

<li class="item-344"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Video Email System">Secure Online Payment.</a></li>

<li class="item-129"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Community based Job Portal">2 Working Days Guarantee.</a></li>

<li class="item-128"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Health, Fitness &amp; Diet Portal">No Hidden Fees and No Traps.</a></li>

<li class="item-130"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Online Buying Network Solution Application">Money Back Guarantee if Declined.</a></li>

<li class="item-127"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Streaming Videos and Social Networking">Prompt Responses</a></li>



</ul>

  <a href="<?php echo BASETHEMEPATH;?>index.php/application" class="ka_button small_button small_cherry">Apply Now!</a>

</div>

</div>

</div>

</div>  

</div> 





				</aside>         </div><!-- END main-area -->                  <div id="footer-top">&nbsp;</div>      </div>