
         
         
         <!-- ***************** - Main Content Area - ***************** -->
         <div id="main">
            <div class="main-area">
            
              <!-- ***************** - Breadcrumbs Start Here - ***************** -->
               <div class="tools">
                 <span class="tools-top"></span>
                 <div class="frame">
                    <h1>Car Pick up Application</h1>
                    <!--<form role="search" method="get" action="template-blog.html" class="search-form">
                       <fieldset>
                          <label for="s">Search this website</label>
                          <span class="text">
                          <input type="text" name="s" class="s" id="s" value="Search" onfocus="this.value=(this.value=='Search') ? '' : this.value;" onblur="this.value=(this.value=='') ? 'Search' : this.value;" />
                         <input type="submit" value="search" class="searchsubmit" />
                          </span>
                       </fieldset>
                    </form>-->
                    <!--<p class="breadcrumb"><a href="index.html">Home</a><span class='current_crumb'>Smartphone </span></p>-->
                     <a class="ka_button small_button small_cherry search_form" href="<?=base_url();?>index.php/application">Apply Now</a><p class="breadcrumb"><a href="<?php echo BASETHEMEPATH;?>index.php/home">Home</a><a href="<?php echo BASETHEMEPATH;?>index.php/about-us">About Us</a><span class='current_crumb'>Extra Services</span>	
                 </div><!-- END frame -->
                 
                 <span class="tools-bottom"></span>
              </div><!-- END tools -->
              
              <main role="main" id="content" class="content_full_width contact_smartphone_content">
              <div class="two_thirds">
                 
<!-- ***************** - START Contact Form - ***************** -->
   
	
    
    
    <div class="one_half tt-column">
                    
                       

                       
                     <div role='form' id='contact-form-8801'>
                        <form action='#tt-contact-notify' method='post' class='contact-form commentsblock'>
                          

      <h2>Needing Extra Service ?</h2>

<p>Please complete the form then we contact to you soon.  </p>            
                   
 <!--<h3 class="apphead">1.What You need?</h3> -->    
               
<div class="element-wrapper phone-element-wrapper clearfix">
<label for="">Airport Fast Track?<span class="rdclr">*</span></label>
<div class="input-wrapper phone-input-wrapper">
<input id="" class="hasDatepicker" type="radio" value="VIP" name="VIP" >VIP
<input id="" class="hasDatepicker" type="radio" value="Normal" name="Normal">Normal
<input id="" class="hasDatepicker" type="radio" value="No" name="No" >No
</div>
</div>       

<div class="element-wrapper phone-element-wrapper clearfix">
<label for="">Car Pick-up?<span class="rdclr">*</span></label>
<div class="input-wrapper phone-input-wrapper">
<input id="" class="hasDatepicker" type="radio" value="Yes" name="Yes" >Yes
<input id="" class="hasDatepicker" type="radio" value="No" name="No" >No
<select id="travaldocument" required="" name="travaldocument" aria-required="true">
<option value="">Select</option>
<option value="Ordinary Passport">Economic Car</option>
</select>
<select id="travaldocument" required="" name="travaldocument" aria-required="true">
<option value="">Select</option>
<option value="Ordinary Passport">4 Seats</option>
<option value="Ordinary Passport">7 Seats</option>
<option value="Ordinary Passport">16 Seats</option>
<option value="Ordinary Passport">24 Seats</option>
</select>
</div>
</div> 

<div>
<label for='8801' class='name'>Arrival Port/airport <span class="rdclr">*</span></label>
<select id="travaldocument" required="" name="travaldocument" aria-required="true">
<option value="">Select</option>
<option value="Ordinary Passport">Ha Noi(HAN)</option>
<option value="Ordinary Passport">Ha Chi Minh(SGN)</option>
<option value="Ordinary Passport">Da Nang(DAN)</option>
</select>
</div>
                           
<div>
<label for='8801' class='name'>Number Of Persons <span class="rdclr">*</span></label>
<select id="travaldocument" required="" name="travaldocument" aria-required="true">
<option value="">Select</option>
<option value="Ordinary Passport">1 Person</option>
<option value="Ordinary Passport">2 Persons</option>
<option value="Ordinary Passport">3 Persons</option>
<option value="Ordinary Passport">4 Persons</option>
<option value="Ordinary Passport">5 Persons</option>
<option value="Ordinary Passport">6 Persons</option>
<option value="Ordinary Passport">7 Persons</option>
<option value="Ordinary Passport">8 Persons</option>
<option value="Ordinary Passport">9 Persons</option>
<option value="Ordinary Passport">10 Persons</option>
<option value="Ordinary Passport">11 Persons</option>
<option value="Ordinary Passport">12 Persons</option>
<option value="Ordinary Passport">13 Persons</option>
<option value="Ordinary Passport">14 Persons</option>
<option value="Ordinary Passport">15 Persons</option>
</select>
                           </div>
                           
  
 <!--<h3 class="apphead">2. Who we can pickup at the airport?</h3>  -->    
 
 <div>
<label for='8801' class='name'>Welcome Name <span class="rdclr">*</span></label>
<select id="travaldocument" required="" name="travaldocument" aria-required="true">
<option value="">Mr.</option>
<option value="Ordinary Passport">Mrs.</option>
<option value="Ordinary Passport">Mss.</option>
</select>
<input type="text" aria-required="true" name="ped" value="" required class="hasDatepicker" id="ped">
</div>    

<div class="element-wrapper phone-element-wrapper clearfix">
<label for="">
Arrival Date and Time
<span class="rdclr">*</span>
</label>
<div class="input-wrapper phone-input-wrapper">
<input type="text" aria-required="true" name="pid" value="" required class="hasDatepicker" id="pid">
</div>
</div>

<div class="element-wrapper phone-element-wrapper clearfix">
<label for="">Flight Number<span class="rdclr">*</span></label>
<div class="input-wrapper phone-input-wrapper">
<input type="text" aria-required="true" name="pid" value="" required class="hasDatepicker" id="pid">
</div>
</div>                
 
 <!--<h3 class="apphead">3. Who we can contact via Email?</h3>   -->  
<div class="element-wrapper phone-element-wrapper clearfix">
<label for="">Your Full Name:<span class="rdclr">*</span></label>
<div class="input-wrapper phone-input-wrapper">
<input type="text" aria-required="true" name="pid" value="" required class="hasDatepicker" id="pid">
</div>
</div>        
              
<div class="element-wrapper phone-element-wrapper clearfix">
<label for="">Email:<span class="rdclr">*</span></label>
<div class="input-wrapper phone-input-wrapper">
<input type="text" aria-required="true" name="pid" value="" required class="hasDatepicker" id="pid">
</div>
</div>  
  
<div class="element-wrapper phone-element-wrapper clearfix">
<label for="">Phone Number<span class="rdclr">*</span></label>
<div class="input-wrapper phone-input-wrapper">
<input type="text" aria-required="true" name="pid" value="" required class="hasDatepicker" id="pid">
</div>
</div>

<div>
<label class="textarea" for="8801-comment">Message <span class="rdclr">*</span></label>
<textarea rows="20" id="contact-form-comment-8801-comment" name="8801-comment"></textarea>
</div>
 
 
<div class="element-wrapper phone-element-wrapper clearfix">
<label for="">Captha<span class="rdclr">*</span></label>
<div class="input-wrapper phone-input-wrapper">
<input type="text" aria-required="true" name="pid" value="" required class="hasDatepicker" id="pid">
</div>
</div>        
                           
                          
                           <p class='contact-submit'>
                             <a class="ka_button small_button small_cherry" href="">Apply Now!</a>
                              <input type="hidden" id="_wpnonce" name="_wpnonce" value="785c6ccebc" /><input type="hidden" name="_wp_http_referer" value="/Karma-4.0/sliders/karma-jquery-3-slider/" />
                              <input type='hidden' name='contact-form-id' value='8801' />
                           </p>
                        </form>
                     </div>
                  </div>
                  
                  
                  
               
                  
                  <!-- ***************** - END Contact Form - ***************** -->
                  
                  
               
              </div><!-- END two_thirds --><!-- END one_third_last -->
                 
                 
                  
                 
                 
                  
            <aside class="sidebar_blog" id="sidebar" role="complementary">
                                  <div class="sidebar-widget">        
               <div class="tt-icon-box">
						  <span class="fa-stack fa-5x"><i style="color:#E15258;" class="fa fa-circle fa-stack-2x"></i><i class="fa fa-thumbs-o-up fa-stack-1x fa-inverse"></i></span>
						  <h1>3 steps away from a Turkey visa.</h1>
						  <p><strong>Fill out the Secured Form</strong> -  No documents to send off.  <strong>Confirm And Pay</strong> - Get Turkey <strong>Visa by Email</strong></p>
					   </div>
                </div>

				  
					 

				   

				   

							<div class="sidebar-widget">

                            <div class="inner- wrapper">
							<div class="tt-icon-box">
                            <a href="<?php echo BASETHEMEPATH;?>index.php/application"><img src=" <?php echo BASETHEMEPATH;?>images/secure.jpg"></a>

							</div>
							</div>
								</div>

						   

						    <div class="sidebar-widget">                 

								<div class="module_round_box_outer">

								<div class="module_round_box">

								<div class="s5_module_box_1">

								<div class="s5_resize_below_columns_inner s5_module_box_2" style="min-height: 313px;">

								<div class="s5_mod_h3_outer">

								<h3 class="s5_mod_h3"><span class="s5_h3_first">FAQS </span></h3>

								</div>

																				

								<ul class="menu">

								<li class="item-343"><a href="<?php echo BASETHEMEPATH;?>index.php/faq">Can I apply for a student or a job e-Visa?</a></li>

								<li class="item-344"><a href="<?php echo BASETHEMEPATH;?>index.php/faq">How much does cost e-visa?</a></li>

								<li class="item-129"><a href="<?php echo BASETHEMEPATH;?>index.php/faq">
How many days my Turkish e-visa valid?</a></li>

								<li class="item-128"><a href="<?php echo BASETHEMEPATH;?>index.php/faq">Can I have a look Sample e-Visa?</a></li>

								

								</ul>

								  <a href="<?php echo BASETHEMEPATH;?>index.php/faq" class="ka_button small_button small_cherry">Read More</a>

								</div>

								</div>

								</div>

								</div>  

							</div>

				   

					<!--<div class="sidebar-widget">

						<div class="module_round_box_outer">

								<div class="module_round_box">

										<div class="s5_module_box_1">

												<div style="min-height: 313px;" class="s5_resize_below_columns_inner s5_module_box_2">

														<div class="s5_mod_h3_outer">

														<h3 class="s5_mod_h3"><span class="s5_h3_first">Apply With Confidence</span></h3>

														</div>

																										



														<div class="jlnews_slider">

															<div style="height: 1560px; top: -780px;" id="jlnews_slider">

																		<span class="">

																	<a title="Lawyer Application" class="" href="#">

																		Lawyer Application			</a>

																	<div><p>Begonia information systems is in final stages of launching a revolutionary application for lawyers / advocates which enable them to supervise and control their day to day office activities, getting and storing all their data at one place and make to reminders to their clients about their cases. This wonderful concept will be launched very soon in the market.</p> ...</div>

																</span>

																

																	</div>

																	</div>

																	

												</div>

										</div>

								</div>

						</div>

					</div>-->

                 

<div class="sidebar-widget">                 

<div class="module_round_box_outer">

<div class="module_round_box">

<div class="s5_module_box_1">

<div class="s5_resize_below_columns_inner s5_module_box_2" style="min-height: 313px;">

<div class="s5_mod_h3_outer">

<h3 class="s5_mod_h3"><span class="s5_h3_first">Apply With Confidence </span></h3>

</div>

												

<ul class="menu">

<li class="item-343"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Video Email Marketing">Safety, Fastest, Reliable, Save Time.</a></li>

<li class="item-344"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Video Email System">Secure Online Payment.</a></li>

<li class="item-129"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Community based Job Portal">2 Working Days Guarantee.</a></li>

<li class="item-128"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Health, Fitness &amp; Diet Portal">No Hidden Fees and No Traps.</a></li>

<li class="item-130"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Online Buying Network Solution Application">Money Back Guarantee if Declined.</a></li>

<li class="item-127"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Streaming Videos and Social Networking">Prompt Responses</a></li>



</ul>

  <a href="<?php echo BASETHEMEPATH;?>index.php/application" class="ka_button small_button small_cherry">Apply Now!</a>

</div>

</div>

</div>

</div>  

</div> 





				</aside>
              
              
              
              
                  
                  
                  <!-- ////////////////////////////////////////////////////////// -->
                  <!-- ***************** - Content Ends Here - ****************** -->
                  <!-- ////////////////////////////////////////////////////////// -->               
               
               
               

               
               </main><!-- END main #content -->
            </div><!-- END main-area -->
         
         <div id="footer-top">&nbsp;</div>
      </div><!-- END main -->
         
         
      
        