
         
         
         
         
         <!-- ***************** - Main Content Area - ***************** -->
         
         <div id="main" class="tt-slider-karma-custom-jquery-3">
            <div id="tt-slider-full-width" style="background-color: #d3e8f4">
            <div class="jquery3-slider-wrap flexslider">
            <ul class="slides">
               <li class="jqslider karma-slider-video">
                  <div class="slider-content-sub-full-width tt-slider-blank-canvas">
					   <p><img class="aligncenter" alt="" src="<?php echo BASETHEMEPATH;?>images/content-karma-banner-team-members.png" width="980" height="445" /></p>
					</div><!-- END slider-content-sub-full-width -->
					
					</li>
					</ul>
					</div><!-- END jquery3-slider-wrap -->
					
					</div>

                  <div class="main-area">
            
            
            
            
            
            
              <!-- ////////////////////////////////////////////////////////// -->
              <!-- ***************** - Content Start Here - ***************** -->
              <!-- ////////////////////////////////////////////////////////// -->
              
                  <main role="main" id="content" class="content_full_width">
                      <div class="member-wrap">
                         <div class="member-photo">
                            <div class="modern_img_frame modern_square">
                               <div class="img-preload"><img src='<?php echo BASETHEMEPATH;?>images/190x180-child-prodigy.png' alt='' class="attachment-fadeIn" /></div>
                            </div>
                         </div><!-- END member-photo -->
                         
                         <div class="member-bio">
                            <h3 class="team-member-name">1.  Airport Fast-Track Service & VIP Service</h3>
                            <!--<p class="team-member-title">CEO and Producer</p>-->
                                                   
                              <p> Airport Fast-Track service & VIP Service
 
 
This service helps the visitors to getting visa stamping, visa sticker and porter service at Turkey Airpot. It's established to assist visitors at the airport when arrived with the highest satisfy to avoid wasting visitor's valuable time, especially after having a long flight or other personal reasons.</p>
<p>Our representative will handle all entry procedure for you, and it takes just a few minutes. Our service functions at three international airports in Turkey for the passengers of all flights. </p>

<h2 style="float: left; color: rgb(218, 0, 0); font-size: 14px; width: 100%; padding: 10px 0px; text-transform: uppercase; font-weight: bold;">
		Two options for choosing:</h2>
        
        <div style="float: left; width: 100%">
		<table cellspacing="0" cellpadding="0" border="0" width="100%">
			<tbody>
				<tr>
					<td valign="top" style="width: 100%; background-color: #F2F2F2;">
						<div style="padding: 10px; text-align: justify; line-height: 18px; float: left;">
							<h2 style="color: #DF1F26;font-size:14px;"><b>A. FAST TRACK:</b></h2>
							<p>Our staff complete the entry procedure and get your passport stamped at the airport within a few minutes instead of waiting at the Immigration counter yourself. It costs 20 USD/pax only excluding visa stamping fee</a>.</p></div>
					</td>
				</tr>
				<!--<tr>
					<td style="height:10px;">
						&nbsp;</td>
				</tr>-->
				<tr>
					<td valign="top" style="width: 100%; background-color: #F2F2F2;">
						<div style="padding: 10px; text-align: justify; line-height: 18px; float: left;">
							<h2 style="color: #DF1F26;font-size:14px;"><b>B. VIP SERVICE</b></h2>
							<p>VIP service provides solemn ritual for your important guests who come to Turkey on business by commercial flight or charter flight. This service also helps VIPs save their precious time and health guarantee. These VIPs will be greeted at the Aircraft and received special treatments that are intended for diplomatic officers. Our staffs will take care of Immigration check in not including Fast Track, Customs and the other necessary formalities on behalf of them.</p></div>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
    
    <div style="width: 100%; float: left; font-family: Arial,Tahoma,Verdana;padding-top:20px;" class="servicefees">
		<table cellspacing="0" cellpadding="0" align="left" width="100%">
			<tbody>
				<tr>
					<td style="width: 146px;background-color: #F2F2F2;">
						<strong>Airport</strong></td>
					<td style="width: 143px;background-color: #F2F2F2;">
						<b>Tan Son Nhat Airport<br>
						In Ho Chi Minh City</b></td>
					<td style="width: 138px;background-color: #F2F2F2;">
						<span><strong>Noi Bai Airport<br>
						In Hanoi</strong></span></td>
					<td style="width: 138px;background-color: #F2F2F2;">
						<strong>Da nang Airport<br>
						In Da Nang</strong></td>
				</tr>
				<tr>
					<td style="width: 146px;background-color: #F2F2F2;">
						<span><strong>Airport Fast Track</strong></span></td>
					<td style="width: 143px;">
						<span>15 USD/pax</span></td>
					<td style="width: 138px;">
						<span>20 USD/pax</span></td>
					<td style="width: 138px;">
						<span>20 USD/pax</span></td>
				</tr>
				<tr>
					<td style="width: 146px;background-color: #F2F2F2;">
						<strong>VIP Service</strong></td>
					<td style="width: 143px;">
						<span>30 USD/pax</span></td>
					<td style="width: 138px;">
						<span>35 USD/pax</span></td>
					<td style="width: 138px;">
						<span>35 USD/pax</span></td>
				</tr>
			</tbody>
		</table>
	</div>
    
    <div style="padding: 10px; text-align: justify; line-height: 18px; float: left;">
							<h2 style="color: #DF1F26;font-size:14px;"><b>Who is recommended to use this service ?</b></h2>
					<p><img src="images/ico-list.png"> BusinessMen</p>
                    <p><img src="images/ico-list.png"> Those who enters Turkey the first time</p>
                    <p><img src="images/ico-list.png"> Those who needs to speed stamping process up at Turkey airport</p>
                    <p><img src="images/ico-list.png"> Those who enters Turkey and bring goes along with kids</p>
                    <p><img src="images/ico-list.png"> Those who travels in a big group</p>
                    <p><img src="images/ico-list.png"> Pregnant women</p>
                    <p><img src="images/ico-list.png"> Disable people</p>
	 </div>
    
    
    <div style="padding: 10px; text-align: justify; line-height: 18px; float: left;">
    <h2 style="color: #DF1F26;font-size:14px;"><b>HOW AIRPORT FAST-TRACK SERVICE RUNS?</b></h2>
    
    <strong style="color:#da0000;">Step 1: </strong>
    <p>Choosing Airport Fast Track Service item once applying for Turkey visa on Arrival with detailed information of your exact flight number, departure and arrival time (GMT+7) or apply for the service via email or phone with the mentioned information. If your flight is changed, please notify us 24 hours before your landing (except Saturday, Sunday and national holidays)</p>
    <strong style="color:#da0000;">Step 2: </strong>
    <p>Find our staff with the welcoming board having your name on it when your flight lands off Turkey. In case, you cannot find our staff, please give us a call at hotline 0800 133 7567 .</p>
     <strong style="color:#da0000;">Step 3: </strong>
     <p>Give our staff your visa approval letter, entry and exit form, passport, 2 photos and stamping fee (USD 45/person for single entry, and USD 95/person for multiple entry visa) for doing your entry procedure</p>
      <strong style="color:#da0000;">Step 4: </strong>
      <p>Get your passport back with Turkey Visa stamped from our staff.</p>
       <strong style="color:#da0000;">Refund policy 24 working hours: </strong>
       <p>Please confirm with us your flight details 24 working hours in advance so that we can do the Airport Fast Track service for you at our best. Other while, if we have not received your confirmation, no refund will be done if you are not picked up at the airport.</p>
     <br>
     <input type="submit" class="ka-form-submit" value="Apply Fast Track ">
    </div>
                         </div><!-- END member-bio -->
                      </div><!-- END member-wrap -->
                      
                      <div class="member-wrap">
                         <div class="member-photo">
                            <div class="shadow_img_frame shadow_square">
                               <div class="img-preload"><img src='<?php echo BASETHEMEPATH;?>images/190x180-chuck-norris.png' alt='' class="attachment-fadeIn" /></div>
                            </div>
                         </div><!-- END member-photo -->
                         
                         <div class="member-bio">
                            <h3 class="team-member-name">2.Car Pick-up service</h3>
                            <!--<p class="team-member-title">Head of Marketing</p>-->
                            
                              <p> Car Pick-up service Smoothly experience of driving with our considerate drivers who are careful, well-trained and friendly. They will chauffeur on your required destination quickly and safely.</p>
                              <p>
For group of 1 to 12 person(s), you will be offered a private car for your group with the appropriate number of seats and fee as: </p>

<table cellspacing="0" cellpadding="0" align="left" width="100%">
			<tbody>
				<tr>
					<td style="width: 145px;background-color: #F2F2F2;" rowspan="2">
						<span><strong>Transfer/pick up</strong></span></td>
					<td style="width: 282px;background-color: #F2F2F2;">
						<b>Tan Son Nhat Airport<br>
						In Ho Chi Minh City</b></td>
					<td style="width: 282px;background-color: #F2F2F2;">
						<strong>Noi Bai Airport<br>
						In Hanoi</strong></td>
					<td style="width: 282px;background-color: #F2F2F2;">
						<strong>Da nang Airport<br>
						In Da Nang</strong></td>
				</tr>
				<tr>
					<td style="width: 138px;">
						<span>Private Car</span></td>
					<td style="width: 138px;">
						<span>Private Car</span></td>
					<td style="width: 144px;">
						<span>Private Car</span></td>
				</tr>
				<tr>
					<td style="width:145px;background-color: #F2F2F2;">
						<span><strong>4 seats</strong></span></td>
					<td style="width: 138px;">
						<span>20 USD/car</span></td>
					<td style="width: 138px;">
						<span>25 USD/car</span></td>
					<td style="width: 144px;">
						<span>25 USD/car</span></td>
				</tr>
				<tr>
					<td style="width: 145px;background-color: #F2F2F2;">
						<span><strong>7 seats</strong></span></td>
					<td style="width: 138px;">
						<span>25 USD/car</span></td>
					<td style="width: 138px;">
						<span>30 USD/car</span></td>
					<td style="width: 144px;">
						<span>30 USD/car</span></td>
				</tr>
				<tr>
					<td style="width: 145px;background-color: #F2F2F2;">
						<span><strong>16 seats</strong></span></td>
					<td style="width: 138px;">
						<span>35 USD/car</span></td>
					<td style="width: 138px;">
						<span>40 USD/car</span></td>
					<td style="width: 144px;">
						<span>40 USD/car</span></td>
				</tr>
			</tbody>
		</table>
        <div style="padding: 10px; text-align: justify; line-height: 18px; float: left;">
							<h2 style="color: #DF1F26;font-size:14px;"><b>WHY CAR-PICK-UP SERVICE ?</b></h2>
					<p>In order to provide more and more useful services for our valued customers, we offer Car-Pick-Up service from any Turkey airport to your concrete address. Using the service, you will experience with drivers who are careful, and well-trained that will expectingly make you feel safely and confidently right your first minutes in </p>
                    
	 </div>
     
     <div style="padding: 10px; text-align: justify; line-height: 18px; float: left;">
							<h2 style="color: #DF1F26;font-size:14px;"><b> 		HOW TO APPLY FOR CAR-PICK-UP SERVICE ?</b></h2>
					<p>Once you are ready to use our Car-Pick-Up service, please confirm in your visa application form or do not hesitate to contact us by email: sales@turkeyvisapro.com  or make us a call at our hotline 0800 133 7567 . Our kind supporters are more than willing to provide you the best information and guidance. </p>
                   
	 </div>
        <input type="submit" class="ka-form-submit" value="Apply Car Service">
                         </div><!-- END member-bio -->
                      </div><!-- END member-wrap -->
                      
                      <div class="member-wrap">
                         <div class="member-photo">
                            <div class="modern_img_frame modern_square">
                               <div class="img-preload"><img src='<?php echo BASETHEMEPATH;?>images/190x180-jane-doe.png' alt='' class="attachment-fadeIn" /></div>
                            </div>
                         </div><!-- END member-photo -->
                         
                         <div class="member-bio">
                            <h3 class="team-member-name"> 3.Hotel Reservation Service</h3>
                            <!--<p class="team-member-title">Head of Security</p>-->
                                          <p>(www.turkeyvisapro.com) - Besides Turkey visa services at www.turkeyvisapro.com , Turkey Visa Inc has also developed hotel online service at our site. The website focuses on helping travelers worldwide to book their accommodation in Turkey with the best prices available.</p>
                              
<p>Presently, this portal provides travelers with a self-service tool that you can gather yourself all required information of almost all great hotels in Turkey (from 3 to 5 stars) such as hotel descriptions, room types and facilities, clear and updated rates for each room type, and transparent photos of your interested hotels, etc. You may easily base on the available information to evaluate and select the most suitable hotels.</p>

<div style="padding: 10px; text-align: justify; line-height: 18px; float: left;">
							<h2 style="color: #DF1F26;font-size:14px;"><b>To book a room(s) at any hotel in Turkey :</b></h2>
					<p><img src="images/ico-list.png"> Just note a short message with your hotels' names/price ranges when you apply for visa at our site or</p>
                    <p><img src="images/ico-list.png"> Fill out the online form at www.turkeyvisapro.com or</p>
                    <p><img src="images/ico-list.png">   Email us at sales@turkeyvisapro.com , or</p>
                    <p><img src="images/ico-list.png">  Call us at 0800 133 7567 or hotline 0800 133 7567</p>
                    <!--<p><img src="images/ico-list.png"> Those who travels in a big group</p>
                    <p><img src="images/ico-list.png"> Pregnant women</p>
                    <p><img src="images/ico-list.png"> Disable people</p>-->
	 </div>
                            <!--<ul class="social_icons tt_vector_social_icons tt_show_social_title">
                               <li><a title="Twitter" class="twitter" href="#" target="_self">Twitter</a></li>
                               <li><a title="Facebook" class="facebook" href="#" target="_self">Facebook</a></li>
                               <li><a title="Email" class="email" href="#" target="_self">Email</a></li>
                               <li><a title="Linkedin" class="linkedin" href="#" target="_self">Linkedin</a></li>
                               <li class="google-plus"><a title="Google +" class="google +" href="#" target="_self">Google +</a></li>
                               <li><a title="Dribbble" class="dribbble" href="#" target="_self">Dribbble</a></li>
                               <li><a title="Skype" class="skype" href="#" target="_self">Skype</a></li>
                            </ul>-->
                         </div><!-- END member-bio -->
                      </div><!-- END member-wrap -->
                      
                      <div class="member-wrap member-last-item">
                         <div class="member-photo">
                            <div class="shadow_img_frame shadow_square">
                               <div class="img-preload"><img src='<?php echo BASETHEMEPATH;?>images/190x180-john-doe.png' alt='' class="attachment-fadeIn" /></div>
                            </div>
                         </div><!-- END member-photo -->
                         
                         <div class="member-bio">
                            <h3 class="team-member-name">4. Tour Booking service</h3>
                           <!-- <p class="team-member-title">Aerospace Engineer</p>-->
                            <p>Whenever you need help with planning your trip in Turkey, even in rush cases, you can always visit our website www.turkeyvisapro.com, the company's main portal for vacation arrangement, or contact our 24/7 available consultants for help. We offers all types of tours in Turkey, from adventure, classical tours to honeymoon, relaxation or MICE tours and anything in between ranging from budget to luxury types. If you need a tour now, just call us 0800 133 7567 or email us at sales@turkeyvisapro.com to get detailed guide.
</p>
                            <!--<ul class="social_icons tt_vector_social_icons tt_vector_social_color tt_show_social_title">
                               <li><a title="Twitter" class="twitter" href="#" target="_self">Twitter</a></li>
                               <li><a title="Facebook" class="facebook" href="#" target="_self">Facebook</a></li>
                               <li><a title="Email" class="email" href="#" target="_self">Email</a></li>
                               <li><a title="Linkedin" class="linkedin" href="#" target="_self">Linkedin</a></li>
                               <li class="google-plus"><a title="Google +" class="google +" href="#" target="_self">Google +</a></li>
                               <li><a title="Dribbble" class="dribbble" href="#" target="_self">Dribbble</a></li>
                            </ul>-->
                         </div><!-- END member-bio -->
                      </div><!-- END member-wrap -->
                  
                  
                  <!-- ////////////////////////////////////////////////////////// -->
                  <!-- ***************** - Content Ends Here - ****************** -->
                  <!-- ////////////////////////////////////////////////////////// -->               
               
               
               

               
               </main><!-- END main #content -->
            </div><!-- END main-area -->
         
         <div id="footer-top">&nbsp;</div>
      </div><!-- END main -->
         
         
         
