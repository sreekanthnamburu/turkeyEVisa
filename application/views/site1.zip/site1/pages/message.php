    <!-- BEGIN CONTENT WRAPPER -->
	<style>
	.tdfirst{
	font-weight:bold}</style>
    
         
         <!-- ***************** - Main Content Area - ***************** -->
         <div id="main">
            <div class="main-area">
            
            
            
            
            
            
              <!-- ////////////////////////////////////////////////////////// -->
              <!-- ***************** - Content Start Here - ***************** -->
              <!-- ////////////////////////////////////////////////////////// -->
              
              
              <!-- ***************** - Breadcrumbs Start Here - ***************** -->
				<div class="tools">
					<span class="tools-top"></span>
					<div class="frame">
						<h1>Information</h1>
					</div><!-- END frame -->
				</div><!-- END tools -->
                  
                  
                  <main role="main" id="content" class="content_full_width">
               
      <!--<h3>Get Started! It only takes a few minutes</h3>-->
              <!-- Register Form -->													               <h3><?=$message_title?></h3>

<?php echo $message_content;?>

               
               </main><!-- END main #content -->
            </div><!-- END main-area -->
          