<style>

td {
    border-bottom: 1px solid;
    border-top: 1px solid;
    text-align: center;
}
</style>
<div id="main">      
      <div class="main-area">     
	  <!-- ////////////////////////////////////////////////////////// -->     
	  <!-- ***************** - Content Start Here - ***************** -->       
	  <!-- ////////////////////////////////////////////////////////// -->      
	  <!-- ***************** - Breadcrumbs Start Here - ***************** -->    
	  <div class="tools">               <span class="tools-top"></span>               <div class="frame">         
	  <h1>Visa Fees</h1>             
	  
<!--<form class="search-form" action="#" method="get" role="search">	
					 <fieldset>			
					 <label for="s">Search this website</label>		
					 <span class="text">					
<input type="text" onBlur="this.value=(this.value=='') ? 'Search' : this.value;" onFocus="this.value=(this.value=='Search') ? '' : this.value;" value="Search" id="s" class="s" name="s">		
					<input type="submit" class="searchsubmit" value="search">	
					</span>					
					</fieldset>				
					</form>	-->  
<a class="ka_button small_button small_cherry search_form" href="<?=base_url();?>index.php/application">Apply Now</a><p class="breadcrumb"><a href="<?php echo BASETHEMEPATH;?>index.php/home">Home</a><!--<a href="<?php echo BASETHEMEPATH;?>index.php/visa-fees">Visa Fees</a>--><span class='current_crumb'>Visa Fees </span></p>                    </div><!-- END frame -->                  <span class="tools-bottom"></span>                  </div><!-- END tools -->                                                                        <main class="content_full_width" id="content" role="main">                                    <!-- <div class="callout-wrap">                     <span>Building gorgeous pricing tables is an absolute breeze thanks to Karma&#8217;s powerful Pricing table Builder. Insert tables anywhere in your site with only a single shortcode.                     </span>                  </div>end callout-wrap                  <br class="clear"> --><!-- ***************** - START TealGrey Pricing Table - ***************** --><p>To obtain your visa(s) for Turkey, please refer to the tables below to see the Embasy fee amount which are not included professional services..</p>  
<div id="feescontainer">
    
    <div id="feescontent">

        <h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>A</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-afganisthan"><img src="<?php echo BASETHEMEPATH;?>images/countries/afganisthan.jpg">Afganisthan</a> </li>
			<li><a class="lightboxlink" href="#lightbox-albenia"><img src="<?php echo BASETHEMEPATH;?>images/countries/albenia.jpg">Albenia</a></li>
			<li><a class="lightboxlink" href="#lightbox-algeria"><img src="<?php echo BASETHEMEPATH;?>images/countries/algeria.jpg">Algeria</a></li>
			<li><a class="lightboxlink" href="#lightbox-azerbaijan"><img src="<?php echo BASETHEMEPATH;?>images/countries/azerbaijan.jpg">Azerbaijan</a></li>
		</ul>
	   <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-andorra"><img src="<?php echo BASETHEMEPATH;?>images/countries/andorra.jpg">Andorra</a></li>
			<li><a class="lightboxlink" href="#lightbox-angola"><img src="<?php echo BASETHEMEPATH;?>images/countries/angola.jpg">Angola</a></li>
			<li><a class="lightboxlink" href="#lightbox-anguilla"><img src="<?php echo BASETHEMEPATH;?>images/countries/anguilla.jpg">Anguilla</a></li>
		</ul>
	   
	   <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-antigua"><img src="<?php echo BASETHEMEPATH;?>images/countries/antigua.jpg">Antigua and Barbuda</a></li>
			<li><a class="lightboxlink" href="#lightbox-argentina"><img src="<?php echo BASETHEMEPATH;?>images/countries/argentina.jpg">Argentina</a></li>
			<li><a class="lightboxlink" href="#lightbox-armenia"><img src="<?php echo BASETHEMEPATH;?>images/countries/armenia.jpg">Armenia</a></li>
		</ul>
	   
	   <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-aruba"><img src="<?php echo BASETHEMEPATH;?>images/countries/aruba.jpg">Aruba</a></li>
			<li><a class="lightboxlink" href="#lightbox-australia"><img src="<?php echo BASETHEMEPATH;?>images/countries/australia.jpg">Australia</a></li>
			<li><a class="lightboxlink" href="#lightbox-austria"><img src="<?php echo BASETHEMEPATH;?>images/countries/austria.jpg">Austria</a></li>
		</ul>
	</div>
		<br class="clear" />
	<div id="feescontent">
		<h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>B</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-bahamas"><img src="<?php echo BASETHEMEPATH;?>images/countries/bahamas.jpg">Bahamas</a> </li>
			<li><a class="lightboxlink" href="#lightbox-bahrain"><img src="<?php echo BASETHEMEPATH;?>images/countries/bahrain.jpg">Bahrain</a></li>
			<li><a class="lightboxlink" href="#lightbox-bangladesh"><img src="<?php echo BASETHEMEPATH;?>images/countries/bangladesh.jpg">Bangladesh</a></li>
			<li><a class="lightboxlink" href="#lightbox-barbados"><img src="<?php echo BASETHEMEPATH;?>images/countries/barbados.jpg">Barbados</a></li>
			<li><a class="lightboxlink" href="#lightbox-belarus"><img src="<?php echo BASETHEMEPATH;?>images/countries/belarus.jpg">Belarus</a></li>
		</ul>
	   <ul class="one_fourth tt_column">	
			<li><a class="lightboxlink" href="#lightbox-belgium"><img src="<?php echo BASETHEMEPATH;?>images/countries/belgium.jpg">Belgium</a></li>
			<li><a class="lightboxlink" href="#lightbox-belize"><img src="<?php echo BASETHEMEPATH;?>images/countries/belize.jpg">Belize</a></li>
			<li><a class="lightboxlink" href="#lightbox-benin"><img src="<?php echo BASETHEMEPATH;?>images/countries/benin.jpg">Benin</a></li>
			<li><a class="lightboxlink" href="#lightbox-bermuda"><img src="<?php echo BASETHEMEPATH;?>images/countries/bermuda.jpg">Bermuda</a></li>
			<li><a class="lightboxlink" href="#lightbox-bhutan"><img src="<?php echo BASETHEMEPATH;?>images/countries/bhutan.jpg">Bhutan</a></li>
		</ul>
	   
	   <ul class="one_fourth tt_column">	
			<li><a class="lightboxlink" href="#lightbox-bolivia"><img src="<?php echo BASETHEMEPATH;?>images/countries/bolivia.jpg">Bolivia</a></li>
			<li><a class="lightboxlink" href="#lightbox-bosnia"><img src="<?php echo BASETHEMEPATH;?>images/countries/bosnia.jpg">Bosnia and Herzegovina</a></li>
			<li><a class="lightboxlink" href="#lightbox-botswana"><img src="<?php echo BASETHEMEPATH;?>images/countries/botswana.jpg">Botswana</a></li>
			<li><a class="lightboxlink" href="#lightbox-brazil"><img src="<?php echo BASETHEMEPATH;?>images/countries/brazil.jpg">Brazil</a></li>
		</ul>
	   
	   <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-brunei"><img src="<?php echo BASETHEMEPATH;?>images/countries/brunei.jpg">Brunei</a></li>
			<li><a class="lightboxlink" href="#lightbox-bulgaria"><img src="<?php echo BASETHEMEPATH;?>images/countries/bulgaria.jpg">Bulgaria</a></li>
			<li><a class="lightboxlink" href="#lightbox-burundi"><img src="<?php echo BASETHEMEPATH;?>images/countries/burundi.jpg">Burundi</a></li>
			<li><a class="lightboxlink" href="#lightbox-bulgaria"><img src="<?php echo BASETHEMEPATH;?>images/countries/bulgaria.jpg">Bulgaria</a></li>
		</ul>
	</div>
	
	<br class="clear" />
	<div id="feescontent">
		<h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>C</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-cambodia"><img src="<?php echo BASETHEMEPATH;?>images/countries/cambodia.jpg">Cambodia</a> </li>
			<li><a class="lightboxlink" href="#lightbox-cameroon"><img src="<?php echo BASETHEMEPATH;?>images/countries/cameroon.jpg">Cameroon</a></li>
			<li><a class="lightboxlink" href="#lightbox-canada"><img src="<?php echo BASETHEMEPATH;?>images/countries/canada.jpg">Canada</a></li>
			<li><a class="lightboxlink" href="#lightbox-cape"><img src="<?php echo BASETHEMEPATH;?>images/countries/cape.jpg">Cape Verde</a></li>
			<li><a class="lightboxlink" href="#lightbox-cayman"><img src="<?php echo BASETHEMEPATH;?>images/countries/cayman.jpg">Cayman Islands</a></li>
		</ul>
	   <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-central"><img src="<?php echo BASETHEMEPATH;?>images/countries/central.jpg">Central African Republic</a></li>
			<li><a class="lightboxlink" href="#lightbox-chad"><img src="<?php echo BASETHEMEPATH;?>images/countries/chad.jpg">Chad</a></li>
			<li><a class="lightboxlink" href="#lightbox-chile"><img src="<?php echo BASETHEMEPATH;?>images/countries/chile.jpg">Chile</a></li>
			<li><a class="lightboxlink" href="#lightbox-china"><img src="<?php echo BASETHEMEPATH;?>images/countries/china.jpg">China</a></li>
			<li><a class="lightboxlink" href="#lightbox-colombia"><img src="<?php echo BASETHEMEPATH;?>images/countries/colombia.jpg">Colombia</a></li>
		</ul>
	   
	   <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-comoros"><img src="<?php echo BASETHEMEPATH;?>images/countries/comoros.jpg">Comoros</a></li>
			<li><a class="lightboxlink" href="#lightbox-congo"><img src="<?php echo BASETHEMEPATH;?>images/countries/congo.jpg">Congo, Republic of the</a></li>
			<li><a class="lightboxlink" href="#lightbox-congo"><img src="<?php echo BASETHEMEPATH;?>images/countries/congo1.jpg">Congo, Domestic</a></li>
			<li><a class="lightboxlink" href="#lightbox-cook"><img src="<?php echo BASETHEMEPATH;?>images/countries/cook.jpg">Cook Islands</a></li>
			<li><a class="lightboxlink" href="#lightbox-costa"><img src="<?php echo BASETHEMEPATH;?>images/countries/costa.jpg">Costa Rica</a></li>
		</ul>
	   
	    <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-cote"><img src="<?php echo BASETHEMEPATH;?>images/countries/cote.jpg">Cote d'Ivoire</a></li>
			<li><a class="lightboxlink" href="#lightbox-croatia"><img src="<?php echo BASETHEMEPATH;?>images/countries/croatia.jpg">Croatia</a></li>
			<li><a class="lightboxlink" href="#lightbox-cuba"><img src="<?php echo BASETHEMEPATH;?>images/countries/cuba.jpg">Cuba</a></li>
			<li><a class="lightboxlink" href="#lightbox-czech"><img src="<?php echo BASETHEMEPATH;?>images/countries/czech.jpg">Czech Republic</a></li>	
		</ul>
	</div>
	<br class="clear" />
	<div id="feescontent">
		<h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>D</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-denmark"><img src="<?php echo BASETHEMEPATH;?>images/countries/denmark.jpg">Denmark</a> </li>
		</ul>
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-djibouti"><img src="<?php echo BASETHEMEPATH;?>images/countries/djibouti.jpg">Djibouti</a></li>
		</ul>
	   
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-dominica"><img src="<?php echo BASETHEMEPATH;?>images/countries/dominica.jpg">Dominica</a></li>
		</ul>
	   
	    <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-dominican"><img src="<?php echo BASETHEMEPATH;?>images/countries/dominican.jpg">Dominican Republic</a></li>	
		</ul>
	</div>
	<br class="clear" />
	<div id="feescontent">
		<h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>E</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-ecuador"><img src="<?php echo BASETHEMEPATH;?>images/countries/ecuador.jpg">Ecuador</a> </li>
			<li><a class="lightboxlink" href="#lightbox-eritrea"><img src="<?php echo BASETHEMEPATH;?>images/countries/eritrea.jpg">Eritrea</a> </li>
		</ul>
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-egypt"><img src="<?php echo BASETHEMEPATH;?>images/countries/egypt.jpg">Egypt</a></li>
			<li><a class="lightboxlink" href="#lightbox-estonia"><img src="<?php echo BASETHEMEPATH;?>images/countries/estonia.jpg">Estonia</a></li>
			
		</ul>
	   
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-el"><img src="<?php echo BASETHEMEPATH;?>images/countries/el.jpg">El Salvador</a></li>
			<li><a class="lightboxlink" href="#lightbox-ethiopia"><img src="<?php echo BASETHEMEPATH;?>images/countries/ethiopia.jpg">Ethiopia</a></li>
		</ul>
	   
	    <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-equatorial"><img src="<?php echo BASETHEMEPATH;?>images/countries/equatorial.jpg">Equatorial Guinea</a></li>	
		</ul>
	</div>
	<br class="clear" />
	<div id="feescontent">
		<h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>F</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-faroe"><img src="<?php echo BASETHEMEPATH;?>images/countries/faroe.jpg">Faroe Islands</a> </li>	
		</ul>
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-fiji"><img src="<?php echo BASETHEMEPATH;?>images/countries/fiji.jpg">Fiji</a></li>
		</ul>
	   
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-finland"><img src="<?php echo BASETHEMEPATH;?>images/countries/finland.jpg">Finland</a></li>
		</ul>
	   
	    <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-france"><img src="<?php echo BASETHEMEPATH;?>images/countries/france.jpg">France</a></li>	
		</ul>
	</div>
		   
		   <br class="clear" />
	<div id="feescontent">
		<h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>G</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-gabon"><img src="<?php echo BASETHEMEPATH;?>images/countries/gabon.jpg">Gabon</a> </li>
			<li><a class="lightboxlink" href="#lightbox-gambia"><img src="<?php echo BASETHEMEPATH;?>images/countries/gambia.jpg">Gambia</a></li>
			<li><a class="lightboxlink" href="#lightbox-georgia"><img src="<?php echo BASETHEMEPATH;?>images/countries/georgia.jpg">Georgia</a></li>
			<li><a class="lightboxlink" href="#lightbox-germany"><img src="<?php echo BASETHEMEPATH;?>images/countries/germany.jpg">Germany</a></li>
		</ul>
	   <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-ghana"><img src="<?php echo BASETHEMEPATH;?>images/countries/ghana.jpg">Ghana</a></li>
			<li><a class="lightboxlink" href="#lightbox-greece"><img src="<?php echo BASETHEMEPATH;?>images/countries/greece.jpg">Greece</a></li>
			<li><a class="lightboxlink" href="#lightbox-greek"><img src="<?php echo BASETHEMEPATH;?>images/countries/greek.jpg">Greek Cypriot</a></li>
			<li><a class="lightboxlink" href="#lightbox-greenland"><img src="<?php echo BASETHEMEPATH;?>images/countries/greenland.jpg">Greenland</a></li>
		</ul>
	   
	   <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-grenada"><img src="<?php echo BASETHEMEPATH;?>images/countries/grenada.jpg">Grenada</a></li>
			<li><a class="lightboxlink" href="#lightbox-guadeloupe"><img src="<?php echo BASETHEMEPATH;?>images/countries/guadeloupe.jpg">Guadeloupe</a></li>
			<li><a class="lightboxlink" href="#lightbox-guam"><img src="<?php echo BASETHEMEPATH;?>images/countries/guam.jpg">Guam</a></li>
			<li><a class="lightboxlink" href="#lightbox-guatemala"><img src="<?php echo BASETHEMEPATH;?>images/countries/guatemala.jpg">Guatemala</a></li>
		</ul>
	   
	    <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-guinea"><img src="<?php echo BASETHEMEPATH;?>images/countries/guinea.jpg">Guinea</a></li>
			<li><a class="lightboxlink" href="#lightbox-guinea1"><img src="<?php echo BASETHEMEPATH;?>images/countries/guinea1.jpg">Guinea-Bissau</a></li>
			<li><a class="lightboxlink" href="#lightbox-guyana"><img src="<?php echo BASETHEMEPATH;?>images/countries/guyana.jpg">Guyana</a></li>	
		</ul>
	</div>
	<br class="clear" />
	<div id="feescontent">
		<h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>H</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-haiti"><img src="<?php echo BASETHEMEPATH;?>images/countries/haiti.jpg">Haiti</a> </li>	
			<li><a class="lightboxlink" href="#lightbox-hungary"><img src="<?php echo BASETHEMEPATH;?>images/countries/hungary.jpg">Hungary</a> </li>
		</ul>
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-honduras"><img src="<?php echo BASETHEMEPATH;?>images/countries/honduras.jpg">Honduras</a></li>
		</ul>
	   
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-hong"><img src="<?php echo BASETHEMEPATH;?>images/countries/hong.jpg">Hong Kong (BN(O))</a></li>
		</ul>
	   
	    <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-hong1"><img src="<?php echo BASETHEMEPATH;?>images/countries/hong1.jpg">Hong Kong (S.A.R)</a></li>	
		</ul>
	</div>
	<br class="clear" />
	<div id="feescontent">
		<h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>I</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-iceland"><img src="<?php echo BASETHEMEPATH;?>images/countries/iceland.jpg">Iceland</a> </li>	
			<li><a class="lightboxlink" href="#lightbox-india"><img src="<?php echo BASETHEMEPATH;?>images/countries/india.jpg">India</a> </li>
		</ul>
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-indonesia"><img src="<?php echo BASETHEMEPATH;?>images/countries/indonesia.jpg">Indonesia</a></li>
			<li><a class="lightboxlink" href="#lightbox-iran"><img src="<?php echo BASETHEMEPATH;?>images/countries/iran.jpg">Iran</a></li>
		</ul>
	   
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-iraq"><img src="<?php echo BASETHEMEPATH;?>images/countries/iraq.jpg">Iraq</a></li>
			<li><a class="lightboxlink" href="#lightbox-ireland"><img src="<?php echo BASETHEMEPATH;?>images/countries/ireland.jpg">Ireland</a></li>
		</ul>
	   
	    <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-israel"><img src="<?php echo BASETHEMEPATH;?>images/countries/israel.jpg">Israel</a></li>		
			<li><a class="lightboxlink" href="#lightbox-italy"><img src="<?php echo BASETHEMEPATH;?>images/countries/italy.jpg">Italy</a></li>
		</ul>
	</div>
	<br class="clear" />
	<div id="feescontent">
		<h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>J</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-jamaica"><img src="<?php echo BASETHEMEPATH;?>images/countries/jamaica.jpg">Jamaica</a> </li>		
		</ul>
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-japan"><img src="<?php echo BASETHEMEPATH;?>images/countries/japan.jpg">Japan</a></li>	
		</ul>
	   
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-jordan"><img src="<?php echo BASETHEMEPATH;?>images/countries/jordan.jpg">Jordan</a></li>
		</ul>
	</div>
	<br class="clear" />
	<div id="feescontent">
		<h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>K</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-kazakhstan"><img src="<?php echo BASETHEMEPATH;?>images/countries/kazakhstan.jpg">Kazakhstan</a> </li>	
			<li><a class="lightboxlink" href="#lightbox-kenya"><img src="<?php echo BASETHEMEPATH;?>images/countries/kenya.jpg">Kenya</a></li>
			
		</ul>
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-kiribati"><img src="<?php echo BASETHEMEPATH;?>images/countries/kiribati.jpg">Kiribati</a></li>
			<li><a class="lightboxlink" href="#lightbox-korea"><img src="<?php echo BASETHEMEPATH;?>images/countries/korea.jpg">Korea, Democratic</a></li>
			
		</ul>
	   
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-korea1"><img src="<?php echo BASETHEMEPATH;?>images/countries/korea1.jpg">Korea, Republic of</a></li>
			<li><a class="lightboxlink" href="#lightbox-kosovo"><img src="<?php echo BASETHEMEPATH;?>images/countries/kosovo.jpg">Kosovo</a></li>
			
		</ul>
	   
	    <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-kuwait"><img src="<?php echo BASETHEMEPATH;?>images/countries/kuwait.jpg">Kuwait</a></li>		
			<li><a class="lightboxlink" href="#lightbox-kyrgyzstan"><img src="<?php echo BASETHEMEPATH;?>images/countries/kyrgyzstan.jpg">Kyrgyzstan</a></li>
			
		</ul>
	</div>
	<br class="clear" />
	<div id="feescontent">
		<h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>L</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-laos"><img src="<?php echo BASETHEMEPATH;?>images/countries/laos.jpg">Laos</a> </li>	
			<li><a class="lightboxlink" href="#lightbox-latvia"><img src="<?php echo BASETHEMEPATH;?>images/countries/latvia.jpg">Latvia</a> </li>
			<li><a class="lightboxlink" href="#lightbox-lebanon"><img src="<?php echo BASETHEMEPATH;?>images/countries/lebanon.jpg">Lebanon</a></li>
		</ul>
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-lesotho"><img src="<?php echo BASETHEMEPATH;?>images/countries/lesotho.jpg">Lesotho</a></li>
			<li><a class="lightboxlink" href="#lightbox-liberia"><img src="<?php echo BASETHEMEPATH;?>images/countries/liberia.jpg">Liberia</a></li>
			
		</ul>
	   
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-libya"><img src="<?php echo BASETHEMEPATH;?>images/countries/libya.jpg">Libya</a></li>
			<li><a class="lightboxlink" href="#lightbox-liechtenstein"><img src="<?php echo BASETHEMEPATH;?>images/countries/liechtenstein.jpg">Liechtenstein</a></li>
			
		</ul>
	   
	    <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-lithuania"><img src="<?php echo BASETHEMEPATH;?>images/countries/lithuania.jpg">Lithuania</a></li>
			<li><a class="lightboxlink" href="#lightbox-luxembourg"><img src="<?php echo BASETHEMEPATH;?>images/countries/luxembourg.jpg">Luxembourg</a></li>
			
		</ul>
	</div>
	<br class="clear" />
	<div id="feescontent">
		<h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>M</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-macao"><img src="<?php echo BASETHEMEPATH;?>images/countries/macao.jpg">Macao (S.A.R.)</a></li>		
			<li><a class="lightboxlink" href="#lightbox-macedonia"><img src="<?php echo BASETHEMEPATH;?>images/countries/macedonia.jpg">Macedonia</a></li>
			<li><a class="lightboxlink" href="#lightbox-madagascar"><img src="<?php echo BASETHEMEPATH;?>images/countries/madagascar.jpg">Madagascar</a></li>		
			<li><a class="lightboxlink" href="#lightbox-malawi"><img src="<?php echo BASETHEMEPATH;?>images/countries/malawi.jpg">Malawi</a></li>
			<li><a class="lightboxlink" href="#lightbox-malaysia"><img src="<?php echo BASETHEMEPATH;?>images/countries/malaysia.jpg">Malaysia</a> </li>	
			<li><a class="lightboxlink" href="#lightbox-maldives"><img src="<?php echo BASETHEMEPATH;?>images/countries/maldives.jpg">Maldives</a> </li>
		</ul>
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-mali"><img src="<?php echo BASETHEMEPATH;?>images/countries/mali.jpg">Malia</a></li>
			<li><a class="lightboxlink" href="#lightbox-malta"><img src="<?php echo BASETHEMEPATH;?>images/countries/malta.jpg">Malta</a></li>
			<li><a class="lightboxlink" href="#lightbox-marshall"><img src="<?php echo BASETHEMEPATH;?>images/countries/marshall.jpg">Marshall Islands</a></li>
			<li><a class="lightboxlink" href="#lightbox-martinique"><img src="<?php echo BASETHEMEPATH;?>images/countries/martinique.jpg">Martinique</a></li>
			<li><a class="lightboxlink" href="#lightbox-mauritania"><img src="<?php echo BASETHEMEPATH;?>images/countries/mauritania.jpg">Mauritania</a></li>
			<li><a class="lightboxlink" href="#lightbox-mauritius"><img src="<?php echo BASETHEMEPATH;?>images/countries/mauritius.jpg">Mauritius</a></li>
			
		</ul>
	   
	    <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-mayotte"><img src="<?php echo BASETHEMEPATH;?>images/countries/mayotte.jpg">Mayotte</a></li>
			<li><a class="lightboxlink" href="#lightbox-mexico"><img src="<?php echo BASETHEMEPATH;?>images/countries/mexico.jpg">Mexico</a></li>
			<li><a class="lightboxlink" href="#lightbox-micronesia"><img src="<?php echo BASETHEMEPATH;?>images/countries/micronesia.jpg">Micronesia, Federated</a></li>
			<li><a class="lightboxlink" href="#lightbox-moldova"><img src="<?php echo BASETHEMEPATH;?>images/countries/moldova.jpg">Moldova</a></li>
			<li><a class="lightboxlink" href="#lightbox-monaco"><img src="<?php echo BASETHEMEPATH;?>images/countries/monaco.jpg">Monaco</a></li>
			
		</ul>
	   
	    <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-mongolia"><img src="<?php echo BASETHEMEPATH;?>images/countries/mongolia.jpg">Mongolia</a></li>		
			<li><a class="lightboxlink" href="#lightbox-montenegro"><img src="<?php echo BASETHEMEPATH;?>images/countries/montenegro.jpg">Montenegro</a></li>
			<li><a class="lightboxlink" href="#lightbox-morocco"><img src="<?php echo BASETHEMEPATH;?>images/countries/morocco.jpg">Morocco</a></li>
			<li><a class="lightboxlink" href="#lightbox-mozambique"><img src="<?php echo BASETHEMEPATH;?>images/countries/mozambique.jpg">Mozambique</a></li>
			<li><a class="lightboxlink" href="#lightbox-myanmar"><img src="<?php echo BASETHEMEPATH;?>images/countries/myanmar.jpg">Myanmar</a></li>
			
		</ul>
	</div>
	<br class="clear" />
	<div id="feescontent">

        <h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>N</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-namibia"><img src="<?php echo BASETHEMEPATH;?>images/countries/namibia.jpg">Namibia</a> </li>
			<li><a class="lightboxlink" href="#lightbox-nauru"><img src="<?php echo BASETHEMEPATH;?>images/countries/nauru.jpg">Nauru</a></li>
			<li><a class="lightboxlink" href="#lightbox-nepal"><img src="<?php echo BASETHEMEPATH;?>images/countries/nepal.jpg">Nepal</a></li>
			
		</ul>
	   <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-netherlands"><img src="<?php echo BASETHEMEPATH;?>images/countries/netherlands.jpg">Netherlands</a></li>
			<li><a class="lightboxlink" href="#lightbox-newc"><img src="<?php echo BASETHEMEPATH;?>images/countries/newc.jpg">New Caledonia</a></li>
			<li><a class="lightboxlink" href="#lightbox-newz"><img src="<?php echo BASETHEMEPATH;?>images/countries/newz.jpg">New Zealand</a></li>
			
		</ul>
	   
	   <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-nicaragua"><img src="<?php echo BASETHEMEPATH;?>images/countries/nicaragua.jpg">Nicaragua</a></li>
			<li><a class="lightboxlink" href="#lightbox-niger"><img src="<?php echo BASETHEMEPATH;?>images/countries/niger.jpg">Niger</a></li>
			<li><a class="lightboxlink" href="#lightbox-nigeria"><img src="<?php echo BASETHEMEPATH;?>images/countries/nigeria.jpg">Nigeria</a></li>
			
		</ul>
	   
	   <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-norfolki"><img src="<?php echo BASETHEMEPATH;?>images/countries/norfolki.jpg">Norfolk Island</a></li>
			<li><a class="lightboxlink" href="#lightbox-norway"><img src="<?php echo BASETHEMEPATH;?>images/countries/norway.jpg">Norway</a></li>
			
		</ul>
	</div>
	<br class="clear" />
	<div id="feescontent">
        <h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>O</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-oman"><img src="<?php echo BASETHEMEPATH;?>images/countries/oman.jpg">Oman</a> </li>
		</ul> 
	</div>
		   <br class="clear" />
	<div id="feescontent">

        <h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>P</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-pakistan"><img src="<?php echo BASETHEMEPATH;?>images/countries/pakistan.jpg">Pakistan</a> </li>
			<li><a class="lightboxlink" href="#lightbox-palau"><img src="<?php echo BASETHEMEPATH;?>images/countries/palau.jpg">Palau</a></li>
			<li><a class="lightboxlink" href="#lightbox-palestine"><img src="<?php echo BASETHEMEPATH;?>images/countries/palestine.jpg">Palestine</a></li>	
		</ul>
	   <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-panama"><img src="<?php echo BASETHEMEPATH;?>images/countries/panama.jpg">Panama</a></li>
			<li><a class="lightboxlink" href="#lightbox-papuan"><img src="<?php echo BASETHEMEPATH;?>images/countries/papuan.jpg">Papua New Guinea</a></li>
			<li><a class="lightboxlink" href="#lightbox-paraguay"><img src="<?php echo BASETHEMEPATH;?>images/countries/paraguay.jpg">Paraguay</a></li>	
		</ul>
	   
	   <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-peru"><img src="<?php echo BASETHEMEPATH;?>images/countries/peru.jpg">Peru</a></li>
			<li><a class="lightboxlink" href="#lightbox-philippines"><img src="<?php echo BASETHEMEPATH;?>images/countries/philippines.jpg">Philippines</a></li>
			<li><a class="lightboxlink" href="#lightbox-poland"><img src="<?php echo BASETHEMEPATH;?>images/countries/poland.jpg">Poland</a></li>	
		</ul>
	   
	   <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-portugal"><img src="<?php echo BASETHEMEPATH;?>images/countries/portugal.jpg">Portugal</a></li>
			<li><a class="lightboxlink" href="#lightbox-puertor"><img src="<?php echo BASETHEMEPATH;?>images/countries/puertor.jpg">Puerto Rico</a></li>
		</ul>
	</div>
	<br class="clear" />
	
	<div id="feescontent">
        <h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>Q</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-qatar"><img src="<?php echo BASETHEMEPATH;?>images/countries/qatar.jpg">Qatar</a> </li>	
		</ul>  
	</div>
	<br class="clear" />
	<div id="feescontent">

        <h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>R</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-reunion"><img src="<?php echo BASETHEMEPATH;?>images/countries/reunion.jpg">Reunion</a></li>
		</ul>
		<ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-romania"><img src="<?php echo BASETHEMEPATH;?>images/countries/romania.jpg">Romania</a></li>
		</ul>
		<ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-russianf"><img src="<?php echo BASETHEMEPATH;?>images/countries/russianf.jpg">Russian Federation</a></li>
		</ul>
		<ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-rwanda"><img src="<?php echo BASETHEMEPATH;?>images/countries/rwanda.jpg">Rwanda</a></li>
		</ul>  
	</div>
<br class="clear" />
	<div id="feescontent">

        <h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>S</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-saintk"><img src="<?php echo BASETHEMEPATH;?>images/countries/saintk.jpg">Saint Kitts and Nevis</a> </li>
			<li><a class="lightboxlink" href="#lightbox-saintl"><img src="<?php echo BASETHEMEPATH;?>images/countries/saintl.jpg">Saint Lucia</a></li>
			<li><a class="lightboxlink" href="#lightbox-saintv"><img src="<?php echo BASETHEMEPATH;?>images/countries/saintv.jpg">Saint Vincent and the..</a></li>
			<li><a class="lightboxlink" href="#lightbox-samoa"><img src="<?php echo BASETHEMEPATH;?>images/countries/samoa.jpg">Samoa</a></li>
			<li><a class="lightboxlink" href="#lightbox-sanm"><img src="<?php echo BASETHEMEPATH;?>images/countries/sanm.jpg">San Marino</a></li>
			<li><a class="lightboxlink" href="#lightbox-sao"><img src="<?php echo BASETHEMEPATH;?>images/countries/sao.jpg">Sao Tome and Principe</a></li>
			<li><a class="lightboxlink" href="#lightbox-saudia"><img src="<?php echo BASETHEMEPATH;?>images/countries/saudia.jpg">Saudi Arabia</a></li>
		</ul>
	   <ul class="one_fourth tt_column"> 	
			<li><a class="lightboxlink" href="#lightbox-senegal"><img src="<?php echo BASETHEMEPATH;?>images/countries/senegal.jpg">Senegal</a></li>
			<li><a class="lightboxlink" href="#lightbox-serbia"><img src="<?php echo BASETHEMEPATH;?>images/countries/serbia.jpg">Serbia</a></li>
			<li><a class="lightboxlink" href="#lightbox-seychelles"><img src="<?php echo BASETHEMEPATH;?>images/countries/seychelles.jpg">Seychelles</a></li>
			<li><a class="lightboxlink" href="#lightbox-sierra"><img src="<?php echo BASETHEMEPATH;?>images/countries/sierra.jpg">Sierra Leone</a></li>
			<li><a class="lightboxlink" href="#lightbox-singapore"><img src="<?php echo BASETHEMEPATH;?>images/countries/singapore.jpg">Singapore</a></li>
			<li><a class="lightboxlink" href="#lightbox-slovakia"><img src="<?php echo BASETHEMEPATH;?>images/countries/slovakia.jpg">Slovakia</a></li>
			<li><a class="lightboxlink" href="#lightbox-slovenia"><img src="<?php echo BASETHEMEPATH;?>images/countries/slovenia.jpg">Slovenia</a> </li>
		</ul>
	   
	   <ul class="one_fourth tt_column"> 	
			<li><a class="lightboxlink" href="#lightbox-solomoni"><img src="<?php echo BASETHEMEPATH;?>images/countries/solomoni.jpg">Solomon Islands</a></li>
			<li><a class="lightboxlink" href="#lightbox-somalia"><img src="<?php echo BASETHEMEPATH;?>images/countries/somalia.jpg">Somalia</a></li>
			<li><a class="lightboxlink" href="#lightbox-southa"><img src="<?php echo BASETHEMEPATH;?>images/countries/southa.jpg">South Africa</a></li>
			<li><a class="lightboxlink" href="#lightbox-souths"><img src="<?php echo BASETHEMEPATH;?>images/countries/souths.jpg">South Sudan</a></li>
			<li><a class="lightboxlink" href="#lightbox-spain"><img src="<?php echo BASETHEMEPATH;?>images/countries/spain.jpg">Spain</a></li>
			<li><a class="lightboxlink" href="#lightbox-sril"><img src="<?php echo BASETHEMEPATH;?>images/countries/sril.jpg">Sri Lanka</a></li>
		</ul>
	   
	   <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-sudan"><img src="<?php echo BASETHEMEPATH;?>images/countries/sudan.jpg">Sudan</a></li>
			<li><a class="lightboxlink" href="#lightbox-suriname"><img src="<?php echo BASETHEMEPATH;?>images/countries/suriname.jpg">Suriname</a></li>
			<li><a class="lightboxlink" href="#lightbox-swaziland"><img src="<?php echo BASETHEMEPATH;?>images/countries/swaziland.jpg">Swaziland</a></li>
			<li><a class="lightboxlink" href="#lightbox-sweden"><img src="<?php echo BASETHEMEPATH;?>images/countries/sweden.jpg">Sweden</a></li>
			<li><a class="lightboxlink" href="#lightbox-switzerland"><img src="<?php echo BASETHEMEPATH;?>images/countries/switzerland.jpg">Switzerland</a></li>
			<li><a class="lightboxlink" href="#lightbox-syria"><img src="<?php echo BASETHEMEPATH;?>images/countries/syria.jpg">Syria</a></li>
		</ul>
	</div>
		<br class="clear" />
	<div id="feescontent">

        <h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>T</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-taiwan"><img src="<?php echo BASETHEMEPATH;?>images/countries/taiwan.jpg">Taiwan</a> </li>
			<li><a class="lightboxlink" href="#lightbox-tajikistan"><img src="<?php echo BASETHEMEPATH;?>images/countries/tajikistan.jpg">Tajikistan</a></li>
			<li><a class="lightboxlink" href="#lightbox-tanzania"><img src="<?php echo BASETHEMEPATH;?>images/countries/tanzania.jpg">Tanzania</a></li>
		</ul>
	   <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-thailand"><img src="<?php echo BASETHEMEPATH;?>images/countries/thailand.jpg">Thailand</a></li>
			<li><a class="lightboxlink" href="#lightbox-togo"><img src="<?php echo BASETHEMEPATH;?>images/countries/togo.jpg">Togo</a></li>
			<li><a class="lightboxlink" href="#lightbox-tonga"><img src="<?php echo BASETHEMEPATH;?>images/countries/tonga.jpg">Tonga</a></li>	
		</ul>
	   <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-trinidad"><img src="<?php echo BASETHEMEPATH;?>images/countries/trinidad.jpg">Trinidad and Tobago</a></li>
			<li><a class="lightboxlink" href="#lightbox-tunisia"><img src="<?php echo BASETHEMEPATH;?>images/countries/tunisia.jpg">Tunisia</a></li>
			<li><a class="lightboxlink" href="#lightbox-turkishr"><img src="<?php echo BASETHEMEPATH;?>images/countries/turkishr.jpg">Turkish Republic Of...</a></li>
		</ul>
	   <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-turkmenistan"><img src="<?php echo BASETHEMEPATH;?>images/countries/turkmenistan.jpg">Turkmenistan</a></li>
			<li><a class="lightboxlink" href="#lightbox-turksc"><img src="<?php echo BASETHEMEPATH;?>images/countries/turksc.jpg">Turks and Caicos Islands</a></li>
			<li><a class="lightboxlink" href="#lightbox-tuvalu"><img src="<?php echo BASETHEMEPATH;?>images/countries/tuvalu.jpg">Tuvalu</a></li>	
		</ul>
	</div>
	<br class="clear" />
	<div id="feescontent">

        <h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>U</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-usa"><img src="<?php echo BASETHEMEPATH;?>images/countries/u.s.a.jpg">U.S.A</a> </li>
			<li><a class="lightboxlink" href="#lightbox-uganda"><img src="<?php echo BASETHEMEPATH;?>images/countries/uganda.jpg">Uganda</a></li>
		</ul>
	   <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-ukraine"><img src="<?php echo BASETHEMEPATH;?>images/countries/ukraine.jpg">Ukraine</a></li>
			<li><a class="lightboxlink" href="#lightbox-united"><img src="<?php echo BASETHEMEPATH;?>images/countries/united.jpg">United Arab Emirates</a></li>	
		</ul>
	   <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-unitedkingdom"><img src="<?php echo BASETHEMEPATH;?>images/countries/unitedkingdom.jpg">United Kingdom</a></li>
			<li><a class="lightboxlink" href="#lightbox-uruguay"><img src="<?php echo BASETHEMEPATH;?>images/countries/uruguay.jpg">Uruguay</a></li>	
	   </ul>
	   <ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-uzbekistan"><img src="<?php echo BASETHEMEPATH;?>images/countries/uzbekistan.jpg">Uzbekistan</a></li>
	   </ul>
	</div>

	<br class="clear" />
	<div id="feescontent">
		<h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>V</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-vanuatu"><img src="<?php echo BASETHEMEPATH;?>images/countries/vanuatu.jpg">Vanuatu</a> </li>
		</ul>
		<ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-vatican"><img src="<?php echo BASETHEMEPATH;?>images/countries/vatican.jpg">Vatican</a></li>
		</ul>
		<ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-venezuela"><img src="<?php echo BASETHEMEPATH;?>images/countries/venezuela.jpg">Venezuela</a></li>
		</ul>
		<ul class="one_fourth_last tt_column">
			<li><a class="lightboxlink" href="#lightbox-vietnam"><img src="<?php echo BASETHEMEPATH;?>images/countries/vietnam.jpg">Vietnam</a></li>
		</ul> 
	</div>
	<br class="clear" />
	<div id="feescontent">
		<h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>Y</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-yemen"><img src="<?php echo BASETHEMEPATH;?>images/countries/yemen.jpg">Yemen</a> </li>	
		</ul>   
	</div>
<br class="clear" />
	<div id="feescontent">
        <h2 class="heading-horizontal" style="margin:0px 0 0px 0;"><span>Z</span></h2>
        <ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-zambia"><img src="<?php echo BASETHEMEPATH;?>images/countries/zambia.jpg">Zambia</a> </li>
		</ul>
		<ul class="one_fourth tt_column">
			<li><a class="lightboxlink" href="#lightbox-zimbabwe"><img src="<?php echo BASETHEMEPATH;?>images/countries/zimbabwe.jpg">Zimbabwe</a></li>
		</ul>
	</div>
<br class="clear" />




		
    </div>
	
	
	
                                  


<ul id="lightboxes">
    <li id="close"></li>
    <li class="lightboxdiv" id="lightbox-afganisthan">
        <div class="box">
            <a  class="close" title="close window">x</a>        
            <h3>Afghanistan</h3>
            <p>
                Afghanistan: Ordinary, Special and Service passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their single entry e-Visas valid for one month e-Visas via the website www.turkeyvisapro.com, provided that they meet certain conditions. Diplomatic passport holders are exempted from visa for their travels up to 90 days.
            </p>
			<table width="100%" border="0px">
				<tr>
				  <th>Price USD</th>
				  <th>Valid(Days)</th>
				  <th>Stay (Days)</th>
				  <th>No Of Entries</th>
				</tr>
			  
				<tr>
					<td>$60.00</td>
					<td>180</td>
					<td>30</td>
					<td>Single-Entry</td>
				</tr>
			</table>
		</div>   
    </li>
	
    <li class="lightboxdiv" id="lightbox-albenia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Albenia</h3>
            <p> Albania: Official passport holders, who are appointed to the diplomatic, consular missions or representations of international organizations accredited in Turkey, are exempted from visa for the period of their assignments. Official and ordinary passport holders are exempted from visa for their travels with touristic purposes and transit from Turkey, up to 90 days within six months starting from the first entry date. </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Excempt</td>
						<td>Excempt</td>
						<td>Excempt</td>
						<td>Excempt</td>
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-algeria">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Algeria</h3>
            <p> Official passport holders are exempted from visa for their travels up to 90 days. Ordinary passport holders are required to have visa to enter Turkey.
				Algerian nationals aged below 18 and over 35 holding ordinary passports may get their one month period single entry e-Visas via the website www.turkeyvisapro.com</p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$50.00 </td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-andorra">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Andorra</h3>
            <p> Ordinary and official passport holders are exempted from visa for their travels up to 90 days.</p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Excempt</td>
						<td>Excempt</td>
						<td>Excempt</td>
						<td>Excempt</td>
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-angola">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Angola</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single e-Visas via the website www.turkeyvisapro.com</p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>

						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry</td>
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-anguilla">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Anguilla</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single e-Visas via the website www.turkeyvisapro.com</p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-antigua">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Antigua and Barbuda</h3>
            <p>Official passport holders are exempted from visa for their travels up to 90 days. Ordinary passport holders are required to have visa to enter Turkey and they can obtain their 90 day period multiple entry e-Visas via the website www.turkeyvisapro.com </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00</td>
						<td>180</td>
						<td>90</td>
						<td>Multiplr-Entry</td> 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-argentina">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Argentina</h3>
            <p> Ordinary and official passport holders are exempted from visa for their travels up to 90 days. </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-armenia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Armenia</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders can obtain one-month multiple entry e-Visas via the website www.turkeyvisapro.com</p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$15.00</td>
						<td>180</td>
						<td>90</td>
						<td>Multiple-Entry</td>
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-aruba">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Aruba</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders can obtain one-month multiple entry e-Visas via the website www.turkeyvisapro.com</p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-australia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Australia</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders can obtain three month-multiple entry e-Visas via the website www.turkeyvisapro.com</p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00  	</td>
						<td>180</td>
						<td>90</td>
						<td>	Multiple-Entry</td>
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-austria">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Austria</h3>
            <p>  Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month-multiple entry e-Visas via the website www.turkeyvisapro.com Official passport holders are exempted from visa for their travels up to 90 days </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00  	</td>
						<td>180</td>
						<td>90</td>
						<td>Multiple-Entry</td>
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-azerbaijan">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Azerbaijan</h3>
            <p>  Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month-multiple entry e-Visas via the website www.turkeyvisapro.com Official passport holders are exempted from visa for their travels up to 90 days </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	<li class="lightboxdiv" id="lightbox-bahamas">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Bahamas</h3>
            <p> Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month multiple e-Visas via the website www.turkeyvisapro.com. Official passport holders are exempted from visa for their travels up to 90 days. </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple-Entry </td> 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-bahrain">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Bahrain</h3>
            <p> Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month multiple entry e-Visas via the website www.turkeyvisapro.com. Official passport holders are exempted from visa for their travel up to 90 days.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$80.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple-Entry </td> 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-bangladesh">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Bangladesh</h3>
            <p>   Bangladeshi nationals holding diplomatic and official/service passport are exempted from visa for their travels up to 90 days. Ordinary passport holders are required to have visa. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their single entry e-Visas valid for one month e-Visas via the website www.turkeyvisapro.com.Provided that they meet certain conditions.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00</td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>  	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
		<li class="lightboxdiv" id="lightbox-barbados">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Barbados</h3>
            <p> Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month multiple entry e-Visas via the website www.turkeyvisapro.com. Official passport holders are exempted from visa for their travel up to 90 days.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple-Entry </td> 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-belarus">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Belarus</h3>
            <p>  Ordinary and official passport holders are exempted from visa for their travels up to 30 days.Total period of stay should be no longer than 90 days within 1 year.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>60 </td>
						<td>Multiple-Entry </td> 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-belgium">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Belgium</h3>
            <p>   Ordinary passport holders are required to have visa to enter Turkey. They can obtain three-month multiple entry e-Visas via the website www.turkeyvisapro.com. Official passport holders are exempted from visa for their travels up to 90 days.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple-Entry </td> 		
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-belize">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Belize</h3>
            <p>  Ordinary and official passport holders are exempted from visa for their travels up to 90 days.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td> 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-benin">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Benin</h3>
            <p>  Ordinary, Special and Service passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their single entry e-Visas valid for one month e-Visas via the website www.turkeyvisapro.com. Provided that they meet certain conditions. Diplomatic passport holders are exempted from visa for their travels up to 90 days. </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>  		 
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-bermuda">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Bermuda</h3>
            <p>   Ordinary and official passport holders are exempted from visa for their travels up to 90 days.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible  </td>
						<td>Not Eligible  </td>
						<td>Not Eligible  </td>  		 
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-bhutan">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Bhutan</h3>
            <p>   Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders can get their 15 day period visas from Turkish diplomatic representations abroad.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible  </td>
						<td>Not Eligible  </td>
						<td>Not Eligible  </td>  		 
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-bolivia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Bolivia</h3>
            <p>  Ordinary and official passport holders are exempted from visa for their travels up to 90 days.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt  </td>
						<td>Exempt </td>
						<td>Exempt  </td>  		 
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-bosnia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Bosnia and Herzegovina</h3>
            <p> Ordinary and official passport holders are exempted from visa for their travels up to 60 days.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt  </td>
						<td>Exempt </td>
						<td>Exempt  </td>  		 
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-botswana">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Botswana</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180  </td>
						<td>30  </td>
						<td>Single-Entry  </td>  	 	 		
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-brazil">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Brazil</h3>
            <p>  Official and ordinary passport holders are exempted from visa for their travels up to 90 days.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt</td>
						<td>Exempt </td>  	 	 		
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-brunei">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Brunei</h3>
            <p>  Official and Ordinary passport holders are exempted from visa for their travels up to 90 days within 180 days starting from the first entry date.    </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt</td>
						<td>Exempt </td>  	 	 		
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-bulgaria">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Bulgaria</h3>
            <p>  Diplomatic and service passport holders are exempted from visa for their travels up to 30 days. Ordinary passport holders are exempt from visa for their travels up to 90 days within 6 months starting from the first entry date.</p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt</td>
						<td>Exempt </td>  	 	 		
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-burkina">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Burkina Faso</h3>
            <p>   Diplomatic passport holders are exempted from visa for their travels up to 90 days. Official/service and ordinary passport holders are required to have visa to enter Turkey. Burkinabe passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com</p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180 </td>
						<td>30</td>
						<td>Single-Entry </td>  	 		
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-burundi">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Burundi</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com</p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180 </td>
						<td>30</td>
						<td>Single-Entry </td>  	 		
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-cambodia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Cambodia</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>  	 		
					  </tr>
				</table> 
        </div>
    </li>
	
		<li class="lightboxdiv" id="lightbox-cameroon">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Cameroon</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60 </td>
						<td>180</td>
						<td>30</td>
						<td>Single</td>  	 		
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-canada">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Canada</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders can obtain three-month multiple entry e-Visas via the website www.turkeyvisapro.com
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60 </td>
						<td>180</td>
						<td>90</td>
						<td>Single-Entry</td>  	 		
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-cape">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Cape Verde</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60 </td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry</td>  	
					  </tr>
				</table> 
        </div>
    </li>
	
		<li class="lightboxdiv" id="lightbox-cape">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Cape Verde</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60 </td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry</td>  	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-cayman">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Cayman Islands</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>  	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-central">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Central African Republic</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entity</td>  	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-chad">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Chad</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry</td>  	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-chile">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Chile</h3>
            <p> Ordinary and official passport holders are exempted from visa for their travels up to 90 days.</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-china">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>China</h3>
            <p> Ordinary passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their single entry e-Visas valid for one month e-Visas via the website www.turkeyvisapro.com, provided that they meet certain conditions. Official passport holders are exempted from visa for their travels up to 30 days..</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry</td>   	 	 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-colombia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Colombia</h3>
            <p> Colombian nationals holding diplomatic, official and ordinary passport are exempted from visa for their travels up to 90 days.</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>   	 	 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-comoros">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Comoros</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td> $40.00</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td>   		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-congo">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Congo, Republic of the</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td> $60.00</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td>   		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
		<li class="lightboxdiv" id="lightbox-congo1">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Congo Domestic</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td> $60.00</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td>   		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-cook">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Cook Islands</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>   		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-costa">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Costa Rica</h3>
            <p>  Ordinary and official passport holders are exempted from visa for their travels up to 30 days.</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>   		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-cote">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Cote d'Ivoire</h3>
            <p>  Official and ordinary passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$90</td>
						<td>180</td>
						<td>30</td>
						<td>Single</td>   		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-croatia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Croatia</h3>
            <p>  Official and ordinary passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td> $20.00</td>
						<td>180</td>
						<td>90</td>
						<td>Multiple-Entry</td>  	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-cuba">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Cuba</h3>
            <p>: Ordinary passport holders are required to have visa to enter Turkey. Official passport holders are exempted from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>  	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-czech">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Czech Republic</h3>
            <p> Official and ordinary passport holders are exempted from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-czech">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Czech Republic</h3>
            <p> Official and ordinary passport holders are exempted from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-denmark">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Denmark</h3>
            <p> Official and ordinary passport holders are exempted from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-djibouti">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Djibouti</h3>
            <p> Official passport holders are exempted from visa for their travels up to 90 days within 6 months starting from the first entry date. Ordinary passport holders are required to have visa to enter Turkey. Ordinary passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td> 		 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-dominica">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Dominica</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders can obtain three month-multiple entry e-Visas via the website www.turkeyvisapro.com </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180</td>
						<td>90</td>
						<td>Multiple-Entry </td> 		 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-dominican">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Dominican Republic</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders can obtain three month-multiple entry e-Visas via the website www.turkeyvisapro.com </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180</td>
						<td>90</td>
						<td>Multiple-Entry </td> 		 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-ecuador">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Ecuador</h3>
            <p> Ordinary and official passport holders are exempted from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt </td> 		 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-ecuador">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Ecuador</h3>
            <p> Ordinary and official passport holders are exempted from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt </td> 		 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-egypt">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Egypt</h3>
            <p> Official passport holders are exempted from visa for their travels up to 90 days.
Ordinary passport holders are required to have visa to enter Turkey. Ordinary passport holders may obtain their 30-day single-entry e-Visas via www.turkeyvisapro.com, provided that they have a valid Schengen or OECD visa or residence permit and that they travel to Turkey with Turkish Airlines or Egypt Air.
Besides, those ordinary passport holders who are under 20 or over 45 years old may get their 30-day single-entry e-Visas via the website www.turkeyvisapro.com. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td>  	 	 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-el">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>El Salvador</h3>
            <p> Ordinary and official passport holders are exempted from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt </td>  	 	 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-equatorial">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Equatorial Guinea</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry  </td>  	 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-eritrea">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Eritrea</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry  </td>  	 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-estonia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Estonia</h3>
            <p> Official and ordinary passport holders are exempted from visa for their travels up to 90 days within 6 months starting from the first entry date.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt </td>  	 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-ethiopia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Ethiopia</h3>
            <p>  Ethiopian nationals holding diplomatic passport are exempted from visa for their travels up to 90 days. Official/service and ordinary passport holders are required to have visa. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180</td>
						<td>30</td>
						<td>	Single-Entry </td>    		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-faroe">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Faroe Islands</h3>
            <p>  Ethiopian nationals holding diplomatic passport are exempted from visa for their travels up to 90 days. Official/service and ordinary passport holders are required to have visa. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>	Not Eligible </td>    		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-fiji">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Fiji</h3>
            <p> Ordinary passport holders are required to have visa to enter Turkey. These passport holders may obtain their one-month single-entry e-Visas via the website www.turkeyvisapro.com. They can also get their 90-day multiple-entry visas from Turkish missions. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 	 	 </td>
						<td>180</td>
						<td>30</td>
						<td>	Single-Entry </td>    		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-finland">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Finland</h3>
            <p> Official and Ordinary passport holders are exempted from visa for their travels up to 90 days within 180 days starting from the first entry date.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt 	 </td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt </td>    		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-france">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>France</h3>
            <p> Ordinary and official passport holders are exempted from visa for their travels up to 90 days.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt 	 </td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt </td>    		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
		<li class="lightboxdiv" id="lightbox-france">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>France</h3>
            <p> Ordinary and official passport holders are exempted from visa for their travels up to 90 days.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt 	 </td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt </td>    		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-gabon">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Gabon</h3>
            <p> Gabonese nationals holding diplomatic passport are exempted from visa for their travels up to 90 days. Official/service and ordinary passport holders are required to have visa to enter Turkey. Gabonese passport holders with a valid Schengen or OECD member's visa or residence permit may obtain their 30-day single-entry e-visas via the website www.turkeyvisapro.com </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry  </td>    		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-gambia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Gambia</h3>
            <p> Ordinary, Special and Service passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their single entry e-Visas valid for one month e-Visas via the website www.turkeyvisapro.com, provided that they meet certain conditions. Diplomatic passport holders are exempted from visa for their travels up to 90 days.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not-Eligible						</td>
						<td>Not-Eligible</td>
						<td>Not-Eligible</td>
						<td>Not-Eligible </td>    		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-georgia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Georgia</h3>
            <p>   Ordinary and official passport holders are exempted from visa for their travels up to 90 days.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt  </td>    		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-germany">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Germany</h3>
            <p> Ordinary, Special and Service passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their single entry e-Visas valid for one month e-Visas via the website www.turkeyvisapro.com, provided that they meet certain conditions. Diplomatic passport holders are exempted from visa for their travels up to 90 days.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt  </td>    		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-ghana">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Ghana</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry  </td>    		 	 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-greece">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Greece</h3>
            <p> Ordinary and official passport holders are exempted from visa for their travels up to 90 days.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>    		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-greek">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Greek Cypriot</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. Both official and ordinary passport holders may obtain their 30-day single-entry e-Visas via the website www.turkeyvisapro.com,  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry  </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-greenland">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Greenland</h3>
            <p> Official and ordinary passport holders are exempted from visa for their travels up to 90 days </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td> Not Eligible</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-grenada">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Grenada</h3>
            <p>Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month multiple entry e-Visas via the website www.turkeyvisapro.com. Official passport holders are exempted from visa for their travels up to 90 days  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td> $60.00 		</td>
						<td>180</td>
						<td>90</td>
						<td> Multiple-Entry </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-guadeloupe">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Guadeloupe</h3>
            <p>Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month multiple entry e-Visas via the website www.turkeyvisapro.com. Official passport holders are exempted from visa for their travels up to 90 days  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td> Not Eligible 		</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td> Not Eligible </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
		<li class="lightboxdiv" id="lightbox-guam">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Guam</h3>
            <p>Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month multiple entry e-Visas via the website www.turkeyvisapro.com. Official passport holders are exempted from visa for their travels up to 90 days  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td> Not Eligible 		</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td> Not Eligible </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-guatemala">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Guatemala</h3>
            <p> Official and ordinary passport holders are exempted from visa for their travels up to 90 days.</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td> Exempt 		</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td> Exempt </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-guinea">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Guinea</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>  $60.00 				</td>
						<td>180</td>
						<td>30</td>
						<td> Single-Entry  </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	<li class="lightboxdiv" id="lightbox-guinea1">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Guinea-Bissau</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>  $60.00 				</td>
						<td>180</td>
						<td>30</td>
						<td> Single-Entry  </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-guyana">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Guyana</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders can get their 15 day period visas from Turkish diplomatic representations abroad. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-haiti">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Haiti</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders can obtain three month-multiple entry e-Visas via the website www.turkeyvisapro.com.</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00</td>
						<td>180</td>
						<td>90</td>
						<td>Multiple-Entry</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	

	<li class="lightboxdiv" id="lightbox-honduras">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Honduras</h3>
            <p> Ordinary and official passport holders are exempted from visa for their travels up to 90 days.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-hong">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Hong Kong (BN(O))</h3>
            <p> O Hong Kong Special Administrative Region of the PRC: Ordinary and official "Hong Kong Special Administrative Region of the People's Republic of China ( SAR ) Passport" holders are exempted from visa for their travels up to 90 days. Hong Kong citizens who have "British National Overseas Passport" are subject to visa and they can obtain their three month period multiple entry e-Visas via the website www.turkeyvisapro.com Holders of "Document of Identity for Visa Purposes-Hong Kong (D.I)" must get their visas from the Turkish diplomatic or consular missions abroad. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00  	</td>
						<td>180</td>
						<td>90</td>
						<td>Multiple-Entry</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-hong1">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Hong Kong (S.A.R.)</h3>
            <p>  Hong Kong Special Administrative Region of the PRC: Ordinary and official "Hong Kong Special Administrative Region of the People's Republic of China ( SAR ) Passport" holders are exempted from visa for their travels up to 90 days. Hong Kong citizens who have "British National Overseas Passport" are subject to visa and they can obtain their three month period multiple entry e-Visas via the website www.turkeyvisapro.com Holders of "Document of Identity for Visa Purposes-Hong Kong (D.I)" must get their visas from the Turkish diplomatic or consular missions abroad. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Excempt</td>
						<td>Excempt</td>
						<td>Excempt</td>
						<td>Excempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-hungary">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Hungary</h3>
            <p> Official and Ordinary passport holders are exempted from visa for their travels up to 90 days within 180 days reckoned from the date of first entry.</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-iceland">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Iceland</h3>
            <p> Ordinary and Official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-india">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>India</h3>
            <p> Diplomatic passport holders are exempt from visa for their travels to Turkey up to 90 days. Ordinary, Special and Service passport holders are required to have visa to enter Turkey. Ordinary, Special and Service passport holders with a valid Schengen or OECD member's visa or residence permit may get their single entry e-Visas valid for one month via the website www.turkeyvisapro.com, provided that they meet certain conditions. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$45.00 		</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-indonesia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Indonesia</h3>
            <p> Indonesian nationals holding diplomatic and official/service passport are exempted from visa for their travels up to 30 days. Ordinary passport holders are required to have visa. These passport holders can obtain their one month period entry e-Visas via the website www.turkeyvisapro.com</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$45.00 		</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-iran">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Iran</h3>
            <p> Ordinary and official passport holders are exempted from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-iraq">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Iraq</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$0.00</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entity</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-ireland">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Ireland</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders can obtain three-month multiple entry e-Visas via the website www.turkeyvisapro.com </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 		</td>
						<td>180</td>
						<td>90</td>
						<td>Multiple-Entry </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-israel">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Israel</h3>
            <p>  Ordinary and official passport holders are exempted from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-italy">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Italy</h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-jamaica">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Jamaica</h3>
            <p> Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month multiple entry e-Visas via the website www.turkeyvisapro.com. Official passport holders are exempted from visa for their travels up to 90 days.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 		</td>
						<td>180</td>
						<td>90</td>
						<td>Multiple-Entry </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-japan">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Japan</h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-jordan">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Jordan</h3>
            <p> Diplomatic, official and ordinary passport holders are exempted from visa for their travels with touristic purposes and transit to/from Turkey up to 90 days within six months starting from the first entry date. Diplomatic and official passport holders, who are appointed to the diplomatic, consular missions or representations of international organizations accredited in Turkey, are exempted from visa for the period of their assignments. Truck and bus drivers and co-drivers, crew members of civil airplanes, trains and ships, engaged in international transport of goods and passengers, are exempted from visa for their travels and transit to/from Turkey, up to 90 days within six months, starting from the first entry date.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	<li class="lightboxdiv" id="lightbox-kazakhstan">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Kazakhstan</h3>
            <p> Ordinary and official passport holders are exempted from visa for their travels up to 30 days. . </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-kenya">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Kenya</h3>
            <p> Citizens of Kenya holding diplomatic, official, service and special passport are exempted from visa for their travels and transit to/from Turkey up to 90 days within 180 days, starting from the first entry date. Ordinary passport holders can get their three-month period multi entry visas from Turkish diplomatic representations abroad. Ordinary passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$50.00 	</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-kiribati">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Kiribati</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey.</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-korea">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Korea, Democratic</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary and Official passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry visas from Istanbul Ataturk Airport. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-korea1">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Korea, Republic of</h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-kosovo">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Kosovo</h3>
            <p> Citizens of Kosova holding diplomatic, official and ordinary passport are exempted from visa for their travels with touristic purposes and transit to/from Turkey up to 90 days within six months, starting from the first entry date.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	<li class="lightboxdiv" id="lightbox-kuwait">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Kuwait</h3>
            <p>  Official passport holders are exempt from visa for their travels up to 90 days within last 180 days. Ordinary passport holders are required to have visa to enter Turkey and they can obtain their three-month period multiple entry e-Visas via the website www.evisa.gov.tr or from Turkish diplomatic Representations abroad. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$0.00 	 	</td>
						<td>180</td>
						<td>90</td>
						<td>Multiple-Entry</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-kyrgyzstan">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Kyrgyzstan</h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-laos">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Laos</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	<li class="lightboxdiv" id="lightbox-latvia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Latvia</h3>
            <p>  Ordinary passport holders are exempt from visa requirement for their travels up to 30 (thirty) days. Diplomatic, special and service passport holders are exempt from visa requirement for their travels up to 90 (ninety) days.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li><li class="lightboxdiv" id="lightbox-lebanon">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Lebanon</h3>
            <p> Official and ordinary passport holders are exempted from visa for their travels with touristic purposes and transit to/from Turkey up to 90 days within six months, starting from the first entry date. Diplomatic and official passport holders, who are appointed to the diplomatic, consular missions or representations of international organizations accredited in Turkey, are exempted from visa for the period of their assignments. Truck and bus drivers and co-drivers, crew members of civil airplanes, trains and ships, engaged in international transport of goods and passengers, are exempted from visa for their travels and transit to/from Turkey, up to 90 days within six months, starting from the first entry date. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-lesotho">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Lesotho</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 		</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-liberia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Liberia</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com.</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 	</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry 	</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-libya">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Libya</h3>
            <p>  Citizens of Libya holding diplomatic, special and ordinary passport are exempted from visa for their travels with touristic purposes and transit to/from Turkey up to 90 days within six months, starting from the first entry date.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-liechtenstein">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Liechtenstein</h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-lithuania">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Lithuania</h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-luxembourg">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Luxembourg</h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	<li class="lightboxdiv" id="lightbox-macao">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Macao (S.A.R.)</h3>
            <p> Ordinary and official Macao Special Administrative Region of the People's Republic of China passport holders are exempt from visa for their travels up to 30 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-macedonia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Macedonia</h3>
            <p>Macedonian nationals holding diplomatic, service and ordinary passport are exempted from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-madagascar">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Madagascar</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 		</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-malawi">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Malawi</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com.</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$40.00 		</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-malaysia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Malaysia</h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-maldives">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Maldives</h3>
            <p> Official passport holders are exempt from visa for their travels up to 30 days. Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month multiple entry e-Visas via the website www.turkeyvisapro.com. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 	 	</td>
						<td>180</td>
						<td>90</td>
						<td>Multiple-Entry</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-mali">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Mali</h3>
            <p> Diplomatic passport holders are exempted from visa for their travels up to 90 days. Official/service and ordinary passport holders are required to have visa. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$50.00 	</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-malta">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Malta</h3>
            <p> Official passport holders are exempt from visa for their travels up to 90 days. Ordinary passport holders are required to have visa to enter Turkey. They can obtain three-month multiple entry e-Visas via the website www.turkeyvisapro.com.</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$0.00 	 	</td>
						<td>180</td>
						<td>90</td>
						<td>Multiple-Entry</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-marshall">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Marshall Islands</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-martinique">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Martinique</h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-mauritania">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Mauritania</h3>
            <p> Official passport holders are exempt from visa for their travels up to 90 days. Ordinary passport holders are required to have visa to enter Turkey. They can their 15 day period visa from Turkish diplomatic representations abroad. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$15.00 	</td>
						<td>180</td>
						<td>30</td>
						<td>Multiple-Entry 	</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-mauritius">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Mauritius</h3>
            <p> Official passport holders are exempted from visa for their travels up to 90 days. Ordinary passport holders are required to have visa to enter Turkey. They can obtain one month multiple entry e-Visas via the website www.turkeyvisapro.com. or three month period multi entry visas from Turkish diplomatic representations abroad. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$15.00 	 	</td>
						<td>180</td>
						<td>30</td>
						<td>Multiple-Entry</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-mayotte">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Mayotte</h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-mexico">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Mexico</h3>
            <p> Diplomatic passport holders are exempted from visa for their travels up to 90 days.
Ordinary and service/official passport holders are required to have visa to enter Turkey. Holders of such passports may get their 90-day multiple-entry visas from Turkish missions abroad or obtain their 30-day single-entry e-visas via the website www.turkeyvisapro.com.</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$0.00 		</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-micronesia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Micronesia, Federated</h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-moldova">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Moldova</h3>
            <p>  Ordinary and official passport holders are exempted from visa for their travels up to 90 days within 180 days starting from the date of first entry.</p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$30.00 		</td>
						<td>180</td>
						<td>30</td>
						<td>Multiple-Entry </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-monaco">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Monaco</h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-mongolia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Mongolia</h3>
            <p> Ordinary and official passport holders are exempt from visa up to 30 days for their touristic visits to Turkey. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-montenegro">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Montenegro</h3>
            <p>Official and Ordinary passport holders are exempt from visa for their travels up to 90 days within 6 months starting from the first entry date.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-morocco">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Morocco</h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-mozambique">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Mozambique</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 		</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry </td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-myanmar">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Myanmar</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey.  </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>
						<td>Not Eligible</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3> </h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3> </h3>
            <p> Ordinary and official passport holders are exempt from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  		 			 			 	 	 		 		 	 	 	
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-namibia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Namibia</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. Namibian nationals may get their one month period single entry turkeyvisapro the website  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-nauru">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Nauru</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders can get their 15 day period visas from Turkish diplomatic representations abroad.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-nepal">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Nepal</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. Official passport holders can get one month period visas and ordinary passport holders can get 15 day period visas from Turkish diplomatic representations abroad   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-netherlands">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Netherlands</h3>
            <p>  Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month-multiple entry turkeyvisapro the website www.turkeyvisapro.com Official passport holders are exempt from visa for their travels up to 90 days.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-newc">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>New Caledonia</h3>
            <p>  xxxxxxxxxxxxxxxxxx  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-newz">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>New Zealand</h3>
            <p>  Ordinary and official passport holders are exempt from visa for their travels up to 90 days.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-nicaragua">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Nicaragua</h3>
            <p>  Ordinary and official passport holders are exempt from visa for their travels up to 90 days.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-niger">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Niger</h3>
            <p>  Nigerien nationals holding diplomatic passport are exempted from visa for their travels up to 90 days. Official/service and ordinary passport holders are required to have visa. Nigerien passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-nigeria">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Nigeria</h3>
            <p>  Ordinary, official/service passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their single entry e-Visas valid for one month e-Visas via the website www.turkeyvisapro.com, provided that they meet certain conditions. 
Diplomatic passport holders are exempted from visa for their travels up to 90 days.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$40.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-norfolki">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Norfolk Island</h3>
            <p>  xxxxxxxxxxxxxxx  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-norway">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Norway</h3>
            <p>  Official passport holders are exempt from visa for their travels up to 90 days. Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month-multiple entry e-Visas via the website www.evisa.gov.tr and stay in Turkey up to 90 days within 6 months starting from the first entry date.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
		<li class="lightboxdiv" id="lightbox-oman">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Oman</h3>
            <p>  Official passport holders are exempt from visa for their travels up to 90 days. Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month-multiple entry e-Visas via the website www.turkeyvisapro.com and stay in Turkey up to 90 days within 6 months starting from the first entry date.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-pakistan">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Pakistan</h3>
            <p>  Official passport holders are exempted from visa for their travels to Turkey up to 90 days. Ordinary passport holders are required to have visa to enter Turkey. Ordinary passport holders with a valid Schengen, OECD member's visa or residence permit may get their one month single entry e-Visas via the website www.turkeyvisapro.com   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180</td>
						<td>30 </td>
						<td>Single-Entry </td>
						
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-palau">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Palau</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey.    </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-palestine">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Palestine</h3>
            <p>  Diplomatic, service and special passport holders are exempted from visa for their travels with touristic purposes and transit to/from Turkey up to 90 days within six months, starting from the first entry date. Ordinary passport holders are required to have visa to enter Turkey. Ordinary passport holders may get their three-month multiple entry e-Visas via the website www.turkeyvisapro.com   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-panama">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Panama</h3>
            <p>  Ordinary and official passport holders are exempted from visa up to 90 days within 180 days starting from the first entry date.    </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-papuan">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Papua New Guinea</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey.    </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-paraguay">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Paraguay</h3>
            <p>  Official and Ordinary passport holders are exempted from visa for their travels up to 90 days within 6 months starting from the first entry date.    </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-peru">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Peru</h3>
            <p>  Official and Ordinary passport holders are exempted from visa for their travels up to 90 days within 180 days.    </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-philippines">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Philippines</h3>
            <p>  Nationals of the Philippines holding diplomatic and official/service passport are exempted from visa for their travels up to 30 days. 
Ordinary passport holders are required to have visa. Holders of such passports may obtain their 30-day single-entry e-visas via the website www.evisa.gov.tr, provided that they have a valid Schengen or OECD member's visa or residence permit.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-poland">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Poland</h3>
            <p>  Official passport holders are exempted from visa for their travels up to 90 days. Ordinary passport holders are required to have visa to enter Turkey. They can obtain three-month multiple entry e-Visas via the website www.turkeyvisapro.com   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-portugal">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Portugal</h3>
            <p>  Official passport holders are exempted from visa for their travels with touristic purposes and transit to/from Turkey up to 90 days within six months, starting from the first entry date. Ordinary passport holders are required to have visa to enter Turkey.
As of 1 March 2013, Portuguese citizens may also use their valid national identity cards and passports which have expired within the last five years when entering Turkey for touristic purposes. They can obtain their visas through the e-visa system (www.evisa.gov.tr) or upon arrival by submitting identity cards or passports expired within the last five years.
Portuguese citizens who wish to enter Turkey for other purposes such as working, transportation, education, long-term stay etc. should obtain their visas from the Consular Section of the Embassy of the Republic of Turkey in Lisbon by submitting their valid passports.    </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-puertor">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Puerto Rico</h3>
            <p>  xxxxxxxxxxxxxxxxxxxxx  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
		<li class="lightboxdiv" id="lightbox-qatar">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Qatar</h3>
            <p>  Diplomatic, service and special passport holders are exempted from visa for their travels with touristic purposes and transit to/from Turkey up to 90 days within six months, starting from the first entry date. Ordinary passport holders are required to have visa to enter Turkey. Ordinary passport holders may get their three-month multiple entry e-Visas via the website www.turkeyvisapro.com   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$28.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-reunion">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Reunion</h3>
            <p>  xxxxxxxxxxxxxxx   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-romania">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Romania</h3>
            <p> Official and ordinary passport holders are exempted from visa for their travels with touristic purposes up to 90 days within 180 days starting from the first entry date.    </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-russianf">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Russian Federation</h3>
            <p>  Ordinary, service and special passport holders are exempted from visa for their touristic and business travels up to 60 days. Diplomatic passport holders are exempted from visa for their travels up to 90 days.    </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-rwanda">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Rwanda</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$30.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-saintk">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Saint Kitts and Nevis</h3>
            <p>  xxxxxxxxxxxxxxxxxxxx  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-saintl">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Saint Lucia</h3>
            <p>  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-saintv">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Saint Vincent and the..</h3>
            <p>  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-samoa">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Samoa</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-sanm">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>San Marino</h3>
            <p>  Ordinary and official passport holders are exempted from visa for their travels up to 90 days.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-sao">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Sao Tome and Principe</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-saudia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Saudi Arabia</h3>
            <p>  Official passport holders are exempted from visa for their travels to Turkey with touristic purposes up to 90 days within 180 days, starting from the first entry date. Ordinary passport holders are required to have visa to enter Turkey. They can obtain their three month period multiple entry e-Visas via the website www.turkeyvisapro.com  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-senegal">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Senegal</h3>
            <p>  Senegalese nationals holding diplomatic passport are exempted from visa for their travels up to 90 days.
Official/service and ordinary passport holders are required to have visa. Senegalese passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-serbia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Serbia</h3>
            <p>  Diplomatic, official and ordinary passport holders and holders of travel document are exempted from visa for their travels with touristic purposes and transit to/from Turkey up to 90 days within six months, starting from the first entry date. Diplomatic and official passport holders, who are appointed to the diplomatic, consular missions or representations of international organizations accredited in Turkey, are exempted from visa for the period of their assignments. Truck and bus drivers and co-drivers, crew members of civil airplanes, trains and ships, engaged in international transport of goods and passengers, are exempted from visa for their travels and transit to/from Turkey, up to 90 days within six months, starting from the first entry date.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-seychelles">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Seychelles</h3>
            <p>   Seychelles nationals holding diplomatic, official and ordinary passport holders are exempted from visa for their travels up to 90 days.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-sierra">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Sierra Leone</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-singapore">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Singapore</h3>
            <p>  Ordinary and official passport holders are exempted from visa for their travels up to 90 days.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-slovakia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Slovakia</h3>
            <p>  Ordinary passport holders are exempt from visa for their travels to Turkey with touristic purposes up to 90 days within 180 days, starting from the first entry date. Official passport holders are exempt from visa for their travels up to 90 days within 180 days, starting from the first entry date.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-slovenia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Slovenia</h3>
            <p>  Ordinary passport holders are exempted from visa for their travels to Turkey with touristic purposes up to 90 days within 180 days, starting from the first entry date. Official passport holders are exempted from visa for their travels to Turkey up to 90 days within six months.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-solomoni">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Solomon Islands</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders can get their 15 day period visas from Turkish diplomatic representations abroad.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-somalia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Somalia</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-southa">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>South Africa</h3>
            <p>   Ordinary passport holders are required to have visa to enter Turkey. They can obtain one month multiple entry visas at the Turkish border gates and three-month period multiple entry visas from Turkish representations abroad or via the website www.turkeyvisapro.com. Official passport holders are exempted from visa for their travels up to 30 days.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$0.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Multiple-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	
	<li class="lightboxdiv" id="lightbox-souths">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>South Sudan</h3>
            <p>  Diplomatic passport holders are exempted from visa for their travels and transit to/from Turkey up to 90 days within 180 days, starting from the first entry date. Ordinary, service and special passport holders are required to have visa to enter Turkey.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	
	<li class="lightboxdiv" id="lightbox-spain">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Spain</h3>
            <p>  Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month-multiple entry e-Visas via the website www.evisa.gov.tr. Official passport holders are exempted from visa for their travels up to 90 days.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	
	<li class="lightboxdiv" id="lightbox-sril">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Sri Lanka</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	
	
	<li class="lightboxdiv" id="lightbox-sudan">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Sudan</h3>
            <p>  Diplomatic passport holders are exempted from visa for their travels and transit to/from Turkey up to 90 days within 180 days, starting from the first entry date. Ordinary, service and special passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-suriname">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Suriname</h3>
            <p>  Diplomatic, official and ordinary passport holders are required to have visa to enter Turkey.
Surinamese nationals may obtain their 30-day single-entry e-visas via the website www.turkeyvisapro.com  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$45.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-swaziland">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Swaziland</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-sweden">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Sweden</h3>
            <p>  Official and Ordinary passport holders are exempted from visa for their travels up to 90 days within 180 days starting from the first entry date.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	
	<li class="lightboxdiv" id="lightbox-switzerland">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Switzerland</h3>
            <p>  Ordinary and official passport holders are exempted from visa for their travels up to 90 days.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-syria">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Syria</h3>
            <p>  Ordinary and official passport holders are exempted from visa for their travel up to 90 days within 6 months starting from the first entry date.   </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
						<td>Exempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
		<li class="lightboxdiv" id="lightbox-taiwan">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Taiwan</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders may get their single entry e-Visas valid for one month via the website www.turkeyvisapro.com, provided that they meet certain conditions. </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$24.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-tajikistan">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Tajikistan</h3>
            <p>  Ordinary passport holders are exempted from visa for their travels to Turkey up to 30 days within six months, starting from the first entry date. Diplomatic passport holders are exempted from visa for their travels to Turkey up to 90 days within six months, starting from the first entry date. Service passport holders, who are appointed to the diplomatic, consular missions or representations of international organizations accredited in Turkey, are exempted from visa for the period of their assignments. Service passport holders, who are not appointed to Turkey, are exempted from visa for their travels with touristic purposes and transit from Turkey, up to 60 days within six months, starting from the first entry date.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-tanzania">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Tanzania</h3>
            <p>  Tanzanian nationals holding diplomatic and service passport are exempted from visa for their travels up to 90 days. Ordinary passport holders are required to have visa. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$50.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-thailand">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Thailand</h3>
            <p>  Ordinary passport holders are exempted from visa for their travels up to 30 days. Official passport holders are exempted from visa for their travels up to 90 days.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-togo">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Togo</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-tonga">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Tonga</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey. </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-trinidad">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Trinidad and Tobago</h3>
            <p>  Ordinary and official passport holders are exempted from visa for their travels up to 90 days.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-tunisia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Tunisia</h3>
            <p>  Ordinary and official passport holders are exempted from visa for their travels up to 90 days.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-turkishr">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Turkish Republic Of...</h3>
            <p>  Ordinary and official passport holders are exempted from visa.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-turkmenistan">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Turkmenistan</h3>
            <p>  Ordinary and official passport holders are exempt from visa requirement for their travels to Turkey up to 30 days.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-turksc">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Turks and Caicos Islands</h3>
            <p>  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-tuvalu">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Tuvalu</h3>
            <p>  Ordinary and official passport holders are required to have visa to enter Turkey.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
						<td>Not Eligible </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
		<li class="lightboxdiv" id="lightbox-usa">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>U.S.A</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey. They can obtain three month-multiple entry visas from Turkish diplomatic representations abroad and also via the website www.turkeyvisapro.com
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry</td>  	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-uganda">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Uganda</h3>
            <p>  Ordinary passport holders are required to have visa to enter Turkey. They can obtain three month-multiple entry e-Visas via the website www.turkeyvisapro.com Official passport holders are exempted from visa for their travels up to 90 days </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$50.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-ukraine">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Ukraine</h3>
            <p>Ukrainian nationals holding diplomatic and official/service passport are exempted from visa for their travels up to 90 days. Ordinary passport holders are exempted from visa for their travels up to 60 days.
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-united">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>United Arab Emirates</h3>
            <p>  Official passport holders are exempted from visa for their travels up to 90 days. Ordinary passport holders are required to have visa to enter Turkey. Ordinary passport holders can obtain their three-month period multiple entry e-Visas via the website www.turkeyvisapro.com </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180 </td>
						<td>90 </td>
						<td>Multiple </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	<li class="lightboxdiv" id="lightbox-unitedkingdom">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>United Kingdom</h3>
            <p>Diplomatic passport holders are exempted from visa for their travels up to 90 days. Ordinary, service and special passport holders are required to have visa to enter Turkey. Ordinary passport holders can obtain three month-multiple entry e-Visas via the website www.turkeyvisapro.com
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$20.00 </td>
						<td>180</td>
						<td>90</td>
						<td>Multiple</td>  	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	
	
	<li class="lightboxdiv" id="lightbox-uruguay">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Uruguay</h3>
            <p>   Ordinary and official passport holders are exempted from visa for their travels up to 90 days.  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
						<td>Excempt </td>
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-uzbekistan">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Uzbekistan</h3>
            <p>Ordinary passport holders are exempted from visa requirement for their travels to Turkey up to 30 days. Diplomatic passport holders are exempted from visa for their travels to Turkey up to 90 days. Service and special passport holders are required to have visa to enter Turkey.
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  	
					  </tr>
				</table> 
        </div>
    </li>
	
	
	<li class="lightboxdiv" id="lightbox-vanuatu">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Vanuatu</h3>
            <p>Ordinary and official passport holders are required to have visa to enter Turkey. Ordinary passport holders can get their 15 day period visa from Turkish diplomatic representations abroad. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Excempt </td> 
						<td>Excempt </td>
						<td>Excempt</td>
						<td>Excempt</td>  	 		
					  </tr>
				</table> 
        </div>
    </li>
	
		<li class="lightboxdiv" id="lightbox-vatican">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Vatican</h3>
            <p>Ordinary and official passport holders are exempted from visa for their travels up to 90 days. </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  	 		
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-venezuela">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Venezuela</h3>
            <p>Ordinary passport holders are exempted from visa for their travels up to 90 days in each six-month period. Official passport holders are exempted from visa for their travels up to 30 days. 
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>Exempt </td>
						<td>Exempt</td>
						<td>Exempt</td>
						<td>Exempt</td>  	 		
					  </tr>
				</table> 
        </div>
    </li>
	
	<li class="lightboxdiv" id="lightbox-vietnam">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Vietnam</h3>
            <p> Ordinary passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.evisa.gov.tr. Official passport holders are exempted from visa for their travels up to 90 days. 
 </p>
				<table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$45.00 </td> 
						<td>180</td>
						<td>30</td>
						<td>Single-Entry</td>  	
					  </tr>
				</table> 
        </div>
    </li>
	
	
		<li class="lightboxdiv" id="lightbox-yemen">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Yemens</h3>
            <p> Official passport holders are exempted from visa for their travels up to 30 days. Ordinary passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com  </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr>
					  <tr>
						<td>$60.00 </td>
						<td>180 </td>
						<td>30 </td>
						<td>Single-Entry </td> 	 	
					  </tr>
				</table> 
        </div>
    </li>

    <li class="lightboxdiv" id="lightbox-zambia">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>        
            <h3>Zambia</h3>
            <p>
                 Ordinary and official passport holders are required to have visa to enter Turkey. Zambian nationals may get their one month period single entry e-Visas via the website www.evisa.gov.tr. 
            </p>
			<table width="100%" border="0px">
				<tr>
				  <th>Price USD</th>
				  <th>Valid(Days)</th>
				  <th>Stay (Days)</th>
				  <th>No Of Entries</th>
				</tr>
			  
				<tr>
					<td>$50.00</td>
					<td>180</td>
					<td>30</td>
					<td>Single-Entry</td> 	
				</tr>
			</table>
		</div>   
    </li>
	
    <li class="lightboxdiv" id="lightbox-zimbabwe">
        <div class="box">
            <a href="#close" class="close" title="close window">x</a>
            <h3>Zimbabwe</h3>
            <p> Ordinary and official passport holders are required to have visa to enter Turkey. These passport holders with a valid Schengen or OECD member's visa or residence permit may get their one month period single entry e-Visas via the website www.turkeyvisapro.com </p>
                <table width="100%" border="0">
					 <tr>
						  <th>Price USD</th>
						  <th>Valid(Days)</th>
						  <th>Stay (Days)</th>
						  <th>No Of Entries</th>
					  </tr> 
					  <tr>
						<td>$30.00</td>
						<td>180</td>
						<td>30</td>
						<td>Single-Entry</td>
					  </tr>
				</table> 
        </div>
    </li>
	
		
	
	
	
</ul><!-- ***************** - END TealGrey Pricing Table - ***************** --> 
       <br class="clear">  

<br class="clear"><div style="height:20px;" class="hr_gap"></div>

<div class="one_third tt-column">
				   <div class="tt-icon-box">
					  <span class="fa-stack fa-4x"><i style="color:#00ACED;" class="fa fa-circle fa-stack-2x"></i><i class="fa fa-file-text-o fa-stack-1x fa-inverse"></i></span>
					 <a href="<?php echo BASETHEMEPATH;?>index.php/application"><p><b>Fill out the Secured Form</b></p></a>
				   </div>
				</div>

<div class="one_third tt-column">
				   <div class="tt-icon-box">
					  <span class="fa-stack fa-4x"><i style="color:#00aced;" class="fa fa-circle fa-stack-2x"></i><i class="fa fa-usd fa-3x fa-stack-1x fa-inverse" style="color:white;"></i></span>
					  <a href="<?php echo BASETHEMEPATH;?>index.php/application"><p><b>Confirm And Pay</b></p></a>
				   </div>
				</div>


				<div class="one_third_last tt-column">
				   <div class="tt-icon-box">
					  <span class="fa-stack fa-4x"><i class="fa fa-circle fa-stack-2x" style="color:#00aced;"></i><i class="fa fa-thumbs-up fa-stack-1x fa-inverse"></i></span>
					 <a href="<?php echo BASETHEMEPATH;?>index.php/application"><p><b>Get Turkey Visa by Email</b></p></a>
				   </div>
				</div>
    </div>
