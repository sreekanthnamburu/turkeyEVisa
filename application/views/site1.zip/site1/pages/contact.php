<div class="tt-slider-" id="main">
			<div class="main-area">
            
            
            
            
            
            
              <!-- ////////////////////////////////////////////////////////// -->
              <!-- ***************** - Content Start Here - ***************** -->
              <!-- ////////////////////////////////////////////////////////// -->
              
              
              <!-- ***************** - Breadcrumbs Start Here - ***************** -->
                  <div class="tools">
				   <span class="tools-top"></span>
				   <div class="frame">
					  <h1>Contact Us</h1>
					 <a class="ka_button small_button small_cherry search_form" href="<?=base_url();?>index.php/application">Apply Now</a><p class="breadcrumb"><a href="<?php echo BASETHEMEPATH;?>index.php/home">Home</a><a href="<?php echo BASETHEMEPATH;?>index.php/about-us">About Us</a><span class='current_crumb'>Contact Us</span></p>
				   </div><!-- END frame -->
				   <span class="tools-bottom"></span>
				</div><!-- END tools -->
				
				<main class="content_blog" id="content" role="main">
				
				<!--<div class="shadow_img_frame shadow_banner_regular">

        <div class="img-preload"><img class="attachment-fadeIn" alt="" src="<?php echo BASETHEMEPATH;?>images/contact-us.jpg" style="display: inline;"></div>

      </div>-->
      <br/>
				<div class="">
              <p>To contact our Customer Service Team online, please fill the form and send message</p>
                 <!--<h3 dir="ltr">We want to hear from you.</h3>
                 <p dir="ltr">The contact form below was created in less than 2 minutes using Karma&#8217;s powerful Form Builder. Contact forms can be inserted into any area of your website including pages, posts, footer and sidebar regions. This form below is for demo purposes only and will mail out to our auto-response system.</p>-->
<!-- ***************** - START Contact Form - ***************** -->
    <div class="one_half tt-column">
                    
                     <div role="form" id="contact-form-8801">
                     
<?php if($message) { echo $message; }?>
                        <form action="contact/send" id="contact_form" method="post" validate="no-validate" class="reg-form input-blocks clearfix">
                           <div>
                              <label for="8801-name" class="name">Your Name <span class="rdclr">*</span></label>
                              <input type="text" name="name" id="name" value="" class="name" required>
                           </div>
                           <div>
                              <label for="8801-email" class="grunion-field-label email">Email <span class="rdclr">*</span></label>
                              <input type="text" name="email" id="email" value="" class="email" required>
                           </div>
                           <div>
                              <label for="8801-Phonenumber" class="grunion-field-label email">Subject <span class="rdclr">*</span></label>
                              <input type="text" name="subject" id="subject" value="" class="Phonenumber" required>
                           </div>
                           <div>
                              <label for="8801-comment" class="textarea">Message <span class="rdclr">*</span></label>
                              <textarea name="comments" id="comments" rows="10" required></textarea>
                           </div>
                           <div class="line">
						   <div>
                              <!--<input type="submit" value="SUBMIT" class="ka_button small_button small_cherry">-->
<input type="submit" name="submit" value="Submit" class="ka_button small_button small_cherry" />
                           </div>
						   </div>
                        </form>
						<script type="text/javascript">
						jQuery(function() {
						jQuery('#contact_form').validate({});
						});
						</script>
                     </div></div>
					     <div class="one_third tt-column">
                 
    <div class="line">
    <h3>Contact Customer Service</h3>
<p>3-5 Excelsior House
Balfour Road,
Ilford, Essex
IG1 4HP</p>
<p>
<strong>UK Customers Toll Free</strong>
<br/>0800 133 7567
</p>
<p>
<strong>Monday to Friday </strong>
<br/>9:30 am to 5:30pm
</p>

<p>
<strong>info@turkeyvisapro.com</strong>
</p>

 </div>
	<!-- ***************** - END Contact Form - ***************** -->
                 <p>&nbsp;</p>
              </div>
               </div>
			   
			   
		<br class="clear"><div style="height:20px;" class="hr_gap"></div>

<div class="one_third tt-column">
				   <div class="tt-icon-box">
					  <span class="fa-stack fa-4x"><i style="color:#00ACED;" class="fa fa-circle fa-stack-2x"></i><i class="fa fa-file-text-o fa-stack-1x fa-inverse"></i></span>
					 <a href="<?php echo BASETHEMEPATH;?>index.php/application"><p><b>Fill out the Secured Form</b></p></a>
				   </div>
				</div>

<div class="one_third tt-column">
				   <div class="tt-icon-box">
					  <span class="fa-stack fa-4x"><i style="color:#00aced;" class="fa fa-circle fa-stack-2x"></i><i class="fa fa-usd fa-3x fa-stack-1x fa-inverse" style="color:white;"></i></span>
					  <a href="<?php echo BASETHEMEPATH;?>index.php/application"><p><b>Confirm And Pay</b></p></a>
				   </div>
				</div>


				<div class="one_third_last tt-column">
				   <div class="tt-icon-box">
					  <span class="fa-stack fa-4x"><i class="fa fa-circle fa-stack-2x" style="color:#00aced;"></i><i class="fa fa-thumbs-up fa-stack-1x fa-inverse"></i></span>
					 <a href="<?php echo BASETHEMEPATH;?>index.php/application"><p><b>Get Turkey Visa by Email</b></p></a>
				   </div>
				</div>	   
			   
			   
			   
			   
			   
			   </main><!-- END main #content -->
			   
			   
			   
<aside class="sidebar_blog" id="sidebar" role="complementary">
                                  <div class="sidebar-widget">        
               <div class="tt-icon-box">
						  <span class="fa-stack fa-5x"><i style="color:#E15258;" class="fa fa-circle fa-stack-2x"></i><i class="fa fa-thumbs-o-up fa-stack-1x fa-inverse"></i></span>
						  <h1>3 steps away from a Turkey visa.</h1>
						  <p><strong>Fill out the Secured Form</strong> -  No documents to send off.  <strong>Confirm And Pay</strong> - Get Turkey <strong>Visa by Email</strong></p>
					   </div>
                </div>

				   <!--<div class="sidebar-widget">               

					<div class="module_round_box_outer">

					<div class="module_round_box">

					<div class="s5_module_box_1">

					<div class="s5_resize_below_columns_inner s5_module_box_2" style="min-height: 313px;">

					<div class="s5_mod_h3_outer">

					<h3 class="s5_mod_h3"><span class="s5_h3_first">Information</span></h3>

					</div>

																	



					<div class="jlnews_slider">

						<div id="jlnews_slider" style="height: 1560px; top: -780px;">

									<span class=""><div><p>Unfortunately if you do a mistake filling e-visa from is invalid and you will need to process a new one. So we have a strict no-refund policy.
Please choose your country or region of travel document. People with dual nationality should choose the nationality according to the passport to be used for the travel.
</p> ...</div>
 <a href="<?php echo BASETHEMEPATH;?>index.php/application" class="ka_button small_button small_coolblue">Apply Now!</a>
</span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>-->

                   

					    <!--<div class="sidebar-widget">

                          <div class="info-box info-box__tertiary">

                            <div class="inner- wrapper">

                            <h3 class="info-box-title">Over 30 Years Experience</h3>

                            <h3 class="info-box-title"> We are Fast, Reliable and Safe </h3>

                            <h3 class="info-box-title">No Login or Sign-up required</h3>

                            <h3 class="info-box-title">Secure &amp; Encrypted payment</h3>

                            <h3 class="info-box-title">24/7 online support</h3>

                            <a href="<?php echo BASETHEMEPATH;?>index.php/application" class="ka_button small_button small_coolblue">Apply Now!</a>

                         

                    </div>

					</div>

                 </div>-->

                

					 

				   

				   

							<div class="sidebar-widget">

                            <div class="inner- wrapper">
							<div class="tt-icon-box">

                            <a href="<?php echo BASETHEMEPATH;?>index.php/application"><img src=" <?php echo BASETHEMEPATH;?>images/secure.jpg"></a>

							</div>
							</div>

								</div>

						   

						    <div class="sidebar-widget">                 

								<div class="module_round_box_outer">

								<div class="module_round_box">

								<div class="s5_module_box_1">

								<div class="s5_resize_below_columns_inner s5_module_box_2" style="min-height: 313px;">

								<div class="s5_mod_h3_outer">

								<h3 class="s5_mod_h3"><span class="s5_h3_first">FAQS </span></h3>

								</div>

																				

								<ul class="menu">

								<li class="item-343"><a href="<?php echo BASETHEMEPATH;?>index.php/faq">Can I apply for a student or a job e-Visa?</a></li>

								<li class="item-344"><a href="<?php echo BASETHEMEPATH;?>index.php/faq">How much does cost e-visa?</a></li>

								<li class="item-129"><a href="<?php echo BASETHEMEPATH;?>index.php/faq">
How many days my Turkish e-visa valid?</a></li>

								<li class="item-128"><a href="<?php echo BASETHEMEPATH;?>index.php/faq">Can I have a look Sample e-Visa?</a></li>

								

								</ul>

								  <a href="<?php echo BASETHEMEPATH;?>index.php/faq" class="ka_button small_button small_cherry">Read More</a>

								</div>

								</div>

								</div>

								</div>  

							</div>

				   

					<!--<div class="sidebar-widget">

						<div class="module_round_box_outer">

								<div class="module_round_box">

										<div class="s5_module_box_1">

												<div style="min-height: 313px;" class="s5_resize_below_columns_inner s5_module_box_2">

														<div class="s5_mod_h3_outer">

														<h3 class="s5_mod_h3"><span class="s5_h3_first">Apply With Confidence</span></h3>

														</div>

																										



														<div class="jlnews_slider">

															<div style="height: 1560px; top: -780px;" id="jlnews_slider">

																		<span class="">

																	<a title="Lawyer Application" class="" href="#">

																		Lawyer Application			</a>

																	<div><p>Begonia information systems is in final stages of launching a revolutionary application for lawyers / advocates which enable them to supervise and control their day to day office activities, getting and storing all their data at one place and make to reminders to their clients about their cases. This wonderful concept will be launched very soon in the market.</p> ...</div>

																</span>

																

																	</div>

																	</div>

																	

												</div>

										</div>

								</div>

						</div>

					</div>-->

                 

<div class="sidebar-widget">                 

<div class="module_round_box_outer">

<div class="module_round_box">

<div class="s5_module_box_1">

<div class="s5_resize_below_columns_inner s5_module_box_2" style="min-height: 313px;">

<div class="s5_mod_h3_outer">

<h3 class="s5_mod_h3"><span class="s5_h3_first">Apply With Confidence </span></h3>

</div>

												

<ul class="menu">

<li class="item-343"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Video Email Marketing">Safety, Fastest, Reliable, Save Time.</a></li>

<li class="item-344"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Video Email System">Secure Online Payment.</a></li>

<li class="item-129"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Community based Job Portal">2 Working Days Guarantee.</a></li>

<li class="item-128"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Health, Fitness &amp; Diet Portal">No Hidden Fees and No Traps.</a></li>

<li class="item-130"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Online Buying Network Solution Application">Money Back Guarantee if Declined.</a></li>

<li class="item-127"><a href="<?php echo BASETHEMEPATH;?>index.php/application" title="Streaming Videos and Social Networking">Prompt Responses</a></li>



</ul>

  <a href="<?php echo BASETHEMEPATH;?>index.php/application" class="ka_button small_button small_cherry">Apply Now!</a>

</div>

</div>

</div>

</div>  

</div> 



<!--<div class="sidebar-widget">                 

<div class="module_round_box_outer">

<div class="module_round_box">

<div class="s5_module_box_1">

<div class="s5_resize_below_columns_inner s5_module_box_2" style="min-height: 313px;">

<div class="s5_mod_h3_outer">

<h3 class="s5_mod_h3"><span class="s5_h3_first">Blog</span></h3>

</div>

												

<ul class="menu">

<li class="item-343"><a href="#" title="Video Email Marketing">01/01/15  Happy New Year</a></li>

<li class="item-344"><a href="#" title="Video Email System">15/01/15 azberlajon established embrassy in Turkey</a></li>

<li class="item-129"><a href="#" title="Community based Job Portal">30/01/15 Genuine Turkey visa by Hazran</a></li>

<li class="item-128"><a href="#" title="Health, Fitness &amp; Diet Portal">10/02/15 Genuine Turkey visa by Jebus</a></li>

<li class="item-130"><a href="#" title="Online Buying Network Solution Application">22/02/15 Genuine Turkey visa by Ramlal</a></li>

<li class="item-127"><a href="#" title="Streaming Videos and Social Networking">28/02/15 Genuine Turkey visa by Leela</a></li>

  

</ul>

<a href="<?php echo BASETHEMEPATH;?>index.php/blog" class="ka_button small_button small_coolblue">Read All Posts</a>

</div>

</div>

</div>

</div>  

</div>--> 



				</aside>

				<!-- END sidebar -->
            </div><!-- END main-area -->
         
         <div id="footer-top">&nbsp;</div>
      </div>
    <!-- END CONTENT WRAPPER --> 