
         <div id="main">
            <div class="main-area">
            
            
            
            
            
            
            
              <!-- ***************** - Breadcrumbs Start Here - ***************** -->
               <div class="tools">
                 <span class="tools-top"></span>
                 <div class="frame">
                    <h1>Hotel Reservation</h1>
                    <!--<form role="search" method="get" action="template-blog.html" class="search-form">
                       <fieldset>
                          <label for="s">Search this website</label>
                          <span class="text">
                          <input type="text" name="s" class="s" id="s" value="Search" onfocus="this.value=(this.value=='Search') ? '' : this.value;" onblur="this.value=(this.value=='') ? 'Search' : this.value;" />
                         <input type="submit" value="search" class="searchsubmit" />
                          </span>
                       </fieldset>
                    </form>-->
                    <!--<p class="breadcrumb"><a href="index.html">Home</a><span class='current_crumb'>Smartphone </span></p>-->
                     <a class="ka_button small_button small_cherry search_form" href="<?=base_url();?>index.php/application">Apply Now</a><p class="breadcrumb"><a href="<?php echo BASETHEMEPATH;?>index.php/home">Home</a><a href="<?php echo BASETHEMEPATH;?>index.php/about-us">About Us</a><span class='current_crumb'>Extra Services</span>
                 </div><!-- END frame -->
                 
                 <span class="tools-bottom"></span>
              </div><!-- END tools -->
              
              <main role="main" id="content" class="content_full_width contact_smartphone_content">
              <div class="two_thirds">
                 
<!-- ***************** - START Contact Form - ***************** -->
   
	
    
    
    <div class="one_half tt-column">
                    
                       

                       
                     <div role='form' id='contact-form-8801'>
                        <form action='#tt-contact-notify' method='post' class='contact-form commentsblock'>
                          

                    
                  
 <h3 class="apphead">Make an Hotel Reservation Request</h3> 
 <p>
You will need to fill some information to complete your request.
<br>
We will confirm to you by phone or email within 2 hours.
</p>      

<div class="element-wrapper phone-element-wrapper clearfix">
<label for="">Check in Date<span class="rdclr">*</span></label>
<div class="input-wrapper phone-input-wrapper">
<input type="text" aria-required="true" name="pid" value="" required class="hasDatepicker" id="pid" placeholder="MM/DD/YYYY">
</div>
</div>         
   
   <div class="element-wrapper phone-element-wrapper clearfix">
<label for="">Check Out Date<span class="rdclr">*</span></label>
<div class="input-wrapper phone-input-wrapper">
<input type="text" aria-required="true" name="pid" value="" required class="hasDatepicker" id="pid" placeholder="MM/DD/YYYY">
</div>
</div> 


<div>
<label for='8801' class='name'>Destination <span class="rdclr">*</span></label>
<select id="travaldocument" required="" name="travaldocument" aria-required="true">
<option value="">Select</option>
<option value="Ordinary Passport">Ha Noi(HAN)</option>
<option value="Ordinary Passport">Ha Chi Minh(SGN)</option>
<option value="Ordinary Passport">Da Nang(DAN)</option>
<option value="Ordinary Passport">Ha Noi(HAN)</option>
<option value="Ordinary Passport">Ha Chi Minh(SGN)</option>
<option value="Ordinary Passport">Da Nang(DAN)</option>
<option value="Ordinary Passport">Ha Noi(HAN)</option>
<option value="Ordinary Passport">Ha Chi Minh(SGN)</option>
<option value="Ordinary Passport">Da Nang(DAN)</option>
</select>
</div>

<div>
<label for='8801' class='name'>Budget <span class="rdclr">*</span></label>
<select id="travaldocument" required="" name="travaldocument" aria-required="true">
<option value="">Select</option>
<option value="Ordinary Passport">$10-$50</option>
<option value="Ordinary Passport">$50-$100</option>
<option value="Ordinary Passport">$100-$200</option>
<option value="Ordinary Passport">$200-$300</option>
<option value="Ordinary Passport">$300-$400</option>
<option value="Ordinary Passport">over $400</option>
</select>
</div>

<div>
<label for='8801' class='name'>Star(s) <span class="rdclr">*</span></label>
<select id="travaldocument" required="" name="travaldocument" aria-required="true">
<option value="">Select</option>
<option value="Ordinary Passport">1 Star</option>
<option value="Ordinary Passport">2 Stars</option>
<option value="Ordinary Passport">3 Stars</option>
<option value="Ordinary Passport">4 Stars</option>
<option value="Ordinary Passport">5 Stars</option>
</select>
</div>

<div class="element-wrapper phone-element-wrapper clearfix">
<label for="">Number Of Rooms<span class="rdclr">*</span></label>
<div class="input-wrapper phone-input-wrapper">
<input type="text" aria-required="true" name="pid" value="" required class="hasDatepicker" id="pid" placeholder="MM/DD/YYYY">
</div>
</div>


<div>
<label for='8801' class='name'>Type of Rooms <span class="rdclr">*</span></label>
<select id="travaldocument" required="" name="travaldocument" aria-required="true">
<option value="">Select</option>
<option value="Ordinary Passport">Single</option>
<option value="Ordinary Passport">Double</option>
<option value="Ordinary Passport">Twins</option>
<option value="Ordinary Passport">Tripple</option>
</select>
</div>

 
<div class="element-wrapper phone-element-wrapper clearfix">
<label for="">Your Full Name:<span class="rdclr">*</span></label>
<div class="input-wrapper phone-input-wrapper">
<input type="text" aria-required="true" name="pid" value="" required class="hasDatepicker" id="pid">
</div>
</div>        

<div class="element-wrapper phone-element-wrapper clearfix">
<label for="">Email:<span class="rdclr">*</span></label>
<div class="input-wrapper phone-input-wrapper">
<input type="text" aria-required="true" name="pid" value="" required class="hasDatepicker" id="pid">
</div>
</div>    
<div class="element-wrapper phone-element-wrapper clearfix">
<label for="">Phone Number<span class="rdclr">*</span></label>
<div class="input-wrapper phone-input-wrapper">
<input type="text" aria-required="true" name="pid" value="" required class="hasDatepicker" id="pid">
</div>

<div>
<label class="textarea" for="8801-comment">Message <span class="rdclr">*</span></label>
<textarea rows="20" id="contact-form-comment-8801-comment" name="8801-comment"></textarea>
</div>
</div>   
<div class="element-wrapper phone-element-wrapper clearfix">
<label for="">Captha<span class="rdclr">*</span></label>
<div class="input-wrapper phone-input-wrapper">
<input type="text" aria-required="true" name="pid" value="" required class="hasDatepicker" id="pid">
</div>
</div>        
                           
                          
                           <p class='contact-submit'>
                             <a class="ka_button small_button small_cherry" href="">Apply Now!</a>
                              <input type="hidden" id="_wpnonce" name="_wpnonce" value="785c6ccebc" /><input type="hidden" name="_wp_http_referer" value="/Karma-4.0/sliders/karma-jquery-3-slider/" />
                              <input type='hidden' name='contact-form-id' value='8801' />
                           </p>
                        </form>
                     </div>
                  </div>
                  
                  
                  
               
                  
                  <!-- ***************** - END Contact Form - ***************** -->
                  
                  
               
              </div><!-- END two_thirds -->
              
             
         

        
        
         </main><!-- END main #content -->
            </div><!-- END main-area -->
         
         <div id="footer-top">&nbsp;</div>
      </div><!-- END main -->