<!-- ***************** - Main Content Area - ***************** -->
<div id="main">
<div class="main-area">
  <main role="main" id="content" class="content_full_width">
    <!-- END callout-wrap -->
    <br class="clear" />
    <!-- <div class="hr_gap" style="height:30px;"></div>-->
    <div class="one_half tt-column"> <img src="<?php echo BASETHEMEPATH;?>images/whychoos.jpg"> </div>
    <style>
				  .step-num {
						display: table-cell;
						height: 40px;
						padding-right: 5px;
						width: 40px;
						background-color: rgb(236, 36, 39);
						border-radius: 50%;
						color: rgb(255, 255, 255);
						display: block;
						font-size: 20px;
						height: 40px;
						line-height: 40px;
						text-align: center;
						width: 40px;
					}
					.text
					{
					float: right;
					   margin-left: 60px;
						margin-top: -62px;
					}
				  </style>
    <div class="one_half_last tt-column">
      <h3>Top Ways How You Benefit by Using our Turkey Visa Service!</h3>
      <div class="blog-posts-shortcode-outer-wrap">
        <ul class="tt-recent-posts">
          <li> <a class="tt-recent-post-link" title="Apply Turkey Visa" href="<?=base_url();?>index.php/application">
            <div class="step-num"> <span class="number">1</span> </div>
            <div class="text">
              <h5 class="item-title"><strong><span style="color: #da0000;">You will be dealing with visa specialists with a speed Track Approval History.</span></strong></h5>
            </div>
            </a> </li>
        </ul>
        <ul class="tt-recent-posts">
          <li> <a class="tt-recent-post-link" title="Metro Design Style" href="<?=base_url();?>index.php/application">
            <div class="step-num"> <span class="number">2</span> </div>
            </a><div class="text">
              <h5 class="item-title"><a class="tt-recent-post-link" title="Metro Design Style" href="<?=base_url();?>index.php/application"><strong><span style="color: #da0000;">No need to send passport or any other scan documents.</span></strong></a></h5>
            </div>
             </li>
        </ul>
        <ul class="tt-recent-posts">
          <li> <a class="tt-recent-post-link" title="Optimize WordPress" href="<?=base_url();?>index.php/application">
            <div class="step-num"> <span class="number">3</span> </div>
            <div class="text">
              <h5 class="item-title"><strong><span style="color: #da0000;">Online Turkey Visa Quick and Easy Application 24/7</span></strong></h5>
            </div>
            </a> </li>
        </ul>
        <ul class="tt-recent-posts">
          <li> <a class="tt-recent-post-link" title="Optimize WordPress" href="<?=base_url();?>index.php/application">
            <div class="step-num"> <span class="number">4</span> </div>
            <div class="text">
              <h5 class="item-title"><strong><span style="color: #da0000;">At this point, your application has been submitted for conformation</span></strong></h5>
            </div>
            </a> </li>
        </ul>
        <ul class="tt-recent-posts">
          <li> <a class="tt-recent-post-link" title="Metro Design Style" href="<?=base_url();?>index.php/application">
            <div class="step-num"> <span class="number">5</span> </div>
            <div class="text">
              <h5 class="item-title"><strong><span style="color: #da0000;">Once your payment has been approved and details checked by expert</span></strong></h5>
            </div>
            </a> </li>
        </ul>
        <ul class="tt-recent-posts">
          <li> <a class="tt-recent-post-link" title="Metro Design Style" href="<?=base_url();?>index.php/application">
            <div class="step-num"> <span class="number">6</span> </div>
            <div class="text">
              <h5 class="item-title"><strong><span style="color: #da0000;">your transaction secure with SSl 128 bit encryption</span></strong></h5>
            </div>
            </a> </li>
            </ul>
            <ul class="tt-recent-posts">
         
          <li> <a class="tt-recent-post-link" title="Metro Design Style" href="<?=base_url();?>index.php/application">
            <div class="step-num"> <span class="number">7</span> </div>
            <div class="text">
              <h5 class="item-title"><strong><span style="color: #da0000;">if you Lost visa number or mail will do recovery service</span></strong></h5>
            </div>
            </a> </li></ul>
             <ul class="tt-recent-posts">
          <li> <a class="tt-recent-post-link" title="Metro Design Style" href="<?=base_url();?>index.php/application">
            <div class="step-num"> <span class="number">8</span> </div>
            </a><div class="text">
              <h5 class="item-title"><a class="tt-recent-post-link" title="Metro Design Style" href="<?=base_url();?>index.php/application"><strong><span style="color: #da0000;">Top Notch customer service Free 24/7 support, call or mail our experts anytime</span></strong></a></h5>
            </div>
             </li></ul>
             <ul class="tt-recent-posts">
          <li> <a class="tt-recent-post-link" title="Metro Design Style" href="<?=base_url();?>index.php/application">
            <div class="step-num"> <span class="number">9</span> </div>
            <div class="text">
              <h5 class="item-title"><strong><span style="color: #da0000;">24/7 Online Support for any clarifications regarding Visa eligibility,etc</span></strong></h5>
            </div>
            </a> </li></ul>
             <ul class="tt-recent-posts">
          <li> <a class="tt-recent-post-link" title="Metro Design Style" href="<?=base_url();?>index.php/application">
            <div class="step-num"> <span class="number">10</span> </div>
            <div class="text">
              <h5 class="item-title"><strong><span style="color: #da0000;">Safe and secure processing - Secure 128/256 bit SSL encryption</span></strong></h5>
            </div>
            </a> </li></ul>
             <ul class="tt-recent-posts">
          <li> <a class="tt-recent-post-link" title="Metro Design Style" href="<?=base_url();?>index.php/application">
            <div class="step-num"> <span class="number">11</span> </div>
            <div class="text">
              <h5 class="item-title"><strong><span style="color: #da0000;">Microscopic verification of Application Form by our Visa experts</span></strong></h5>
            </div>
            </a> </li></ul> <ul class="tt-recent-posts">
            
          <li> <a class="tt-recent-post-link" title="Metro Design Style" href="<?=base_url();?>index.php/application">
            <div class="step-num"> <span class="number">12</span> </div>
            </a><div class="text">
              <h5 class="item-title"><a class="tt-recent-post-link" title="Metro Design Style" href="<?=base_url();?>index.php/application"><strong><span style="color: #da0000;">Group applications for Travelers, you can submit applications for a group of up to 10 individuals at one time</span></strong></a></h5>
            </div>
             </li></ul>
             <ul class="tt-recent-posts">
          <li> <a class="tt-recent-post-link" title="Metro Design Style" href="<?=base_url();?>index.php/application">
            <div class="step-num"> <span class="number">13</span> </div>
            <div class="text">
              <h5 class="item-title"><strong><span style="color: #da0000;">100% Money back Guarantee if your visa is denied</span></strong></h5>
            </div>
            </a> </li></ul>
             
      </div>
      <a class="ka_button small_button small_cherry" href="<?php echo BASETHEMEPATH;?>index.php/application">Apply Now!</a> <br class="clear" />
    </div>
    <br class="clear" />
    <p>&nbsp;</p>
    <!-- ////////////////////////////////////////////////////////// -->
    <!-- ***************** - Content Ends Here - ****************** -->
    <!-- ////////////////////////////////////////////////////////// -->
  </main></div>
  <!-- END main #content -->
</div>
<!-- END main-area -->
<div id="footer-top">&nbsp;</div>
</div>
<!-- END main -->
